<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html id="html">
    <head>
        <title>org pentaho libformula ui editor FormulaMessage.java - GrepCode.com - Java Source Code Search 2.0</title>
        <meta name="verify-v1" content="oDbHfknRLVnvs+1b/O61iSxPEhVr3O08Fd3QqJ1cGh8="/>
        <meta name="verify-v1" content="d2G+nnw2Xr6jBfde7yNvdZirW9Y6K0fa+56zhEmm6YA="/>
        <meta name="msvalidate.01" content="62B5A32F828BC27E3852FB825A5156E4" />
        
        <meta property="fb:app_id" content="143989634057"/>
        
        <link rel="search" type="application/opensearchdescription+xml" title="grepcode.com" href="/static/app/grepcodeosd.xml"/>
        <link rel="icon" type="image/x-icon" href="/static/app/images/favicon.ico"/>

        <link href="/static/app/stylesheet/site.css" rel="stylesheet" type="text/css"/>
        <link href="/static/app/stylesheet/images-sprite.css" rel="stylesheet" type="text/css"/>
        <link href="/static/app/stylesheet/images-site-sprite.css" rel="stylesheet" type="text/css"/>

        <!-- always need these -->
        <script type="text/javascript" src="/static/app/javascript/always.js"></script>

        
        

        
        
            <script type="text/javascript" src="/static/app/javascript/grepcode.js"></script>
        

        
        
    </head>

    <body>
        <div id="header">
            <div class="head-search">
                <div class="head-outer">
                    <div class="head-middle">
                        <div class="head-inner">
                            <div>
    <div class="search-panel">
        <form action="/search">
            <span id="query-container">
                <input id="search-field" type="text" name="query" value="org pentaho libformula ui editor FormulaMessage.java"/>
            </span>
            <input type="hidden" name="start" value="0"></input><input type="hidden" name="entity" value="type"></input><input type="hidden" name="n" value=""></input>
            <input type="submit" value="Search"/>
            <span id="search-field-focus-flag" style="display:none;">false</span>
        </form>
    </div>
    <script>
    YAHOO.util.Event.onDOMReady(function() {
        var flag = document.getElementById("search-field-focus-flag");
        if (flag && flag.innerHTML === 'true') {
            document.getElementById("search-field").focus();
        }
    }, null, true)
    </script>
</div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="logo">
                <div class="head-outer">
                    <div class="head-middle">
                        <div class="head-inner">
                            <a href="/"><img src="/static/app/images/logo-rel.gif" alt="Logo" width="200" height="50"/></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="head-menu head-menu-width">
                <div class="head-outer">
                    <div class="head-middle">
                        <div class="head-inner">
                            <span>
			                <a href="/?st=true">Stack Trace Search</a> |
                            </span>
                            <span>
                            <a href="/eclipse">Eclipse</a> |
                            <a href="/intellij">IntelliJ</a> |
                            <a href="/contact">Contact</a> |
                            <a href="/faq">FAQ</a>
                            </span>
                            
                            <span>
                            |
                            <a href="http://blog.grepcode.com/" rel="nofollow"><img title="Our Blog" alt="Blog" src="/static/app/images/site/blog.png" width="16" height="16" border="0"/></a>
                            <a href="http://twitter.com/grepcode/" rel="nofollow"><img title="Follow us on Twitter" alt="Twitter" src="/static/app/images/site/twitter.png" width="16" height="16" border="0"/></a>
                            <a href="http://www.facebook.com/pages/GrepCode/159698964349" rel="nofollow"><img title="Follow us on FaceBook" alt="FaceBook" src="/static/app/images/site/facebook.png" width="16" height="16" border="0"/></a>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
            <script type="text/javascript">
                    var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
                    document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
            </script>
            <script type="text/javascript">
                var pageTracker = _gat._getTracker("UA-7614624-1");
            </script>
        
        
            <script>
                function isGCEnterpriseEdition() {
                    return false;
                }
            </script>
        
        
    <div class="search-tabs">
        <div class="search-tabs-left-panel">
            <div class="search-tabs-left">
                <div class="search-tab-selected">
                    <span class="search-tab-prefix-left"><img class='img_base img_transparent_16_16' src='/static/app/images/1x1.gif' border='0' title='Transparent 16 16' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><span><em><span>All Repositories</span></em></span></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_java' src='/static/app/images/1x1.gif' border='0' title='Java' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$root&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>JDK</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_apache' src='/static/app/images/1x1.gif' border='0' title='Apache' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repo1.maven.org$maven2&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Maven-Central</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_cloudera' src='/static/app/images/1x1.gif' border='0' title='Cloudera' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.cloudera.com$content$repositories$releases&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Cloudera</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_apache' src='/static/app/images/1x1.gif' border='0' title='Apache' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=obelix.ics.uci.edu$nexus$content$groups$hyracks-public-releases&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Hyracks</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_java' src='/static/app/images/1x1.gif' border='0' title='Java' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=maven.java.net$content$groups$promoted&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Java.net</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_jboss' src='/static/app/images/1x1.gif' border='0' title='Jboss' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.jboss.org$nexus$content$repositories$releases&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>JBoss</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_netbeans' src='/static/app/images/1x1.gif' border='0' title='Netbeans' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=bits.netbeans.org$maven2&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>NetBeans</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_pentaho' src='/static/app/images/1x1.gif' border='0' title='Pentaho' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.pentaho.org$artifactory$pentaho&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Pentaho</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_primefaces' src='/static/app/images/1x1.gif' border='0' title='Primefaces' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.primefaces.org&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>PrimeFaces</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_springsource' src='/static/app/images/1x1.gif' border='0' title='Springsource' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.springsource.com&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>SpringSource</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.4.2&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Eclipse-4.4.2</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.4.1&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Eclipse-4.4.1</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.4.0&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Eclipse-4.4.0</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.3.1&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Eclipse-4.3.1</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.3&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Eclipse-4.3</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.2.2&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Eclipse-4.2.2</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.2&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Eclipse-4.2</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$3.7.2&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Eclipse-3.7.2</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$3.6.2&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Eclipse-3.6.2</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=build.eclipse.org$rt$virgo$ivy$bundles$release&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Eclipse-Virgo</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=maven.glassfish.org$content$repositories$eclipselink&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>EclipseLink</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_grepcode' src='/static/app/images/1x1.gif' border='0' title='Grepcode' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$ext&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>GrepCode</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_grepcode' src='/static/app/images/1x1.gif' border='0' title='Grepcode' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$ext-eclipse&amp;start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>GrepCode-Eclipse</span></a></span>
                </div>
            </div><div class="search-tabs-left">
                <div class="search-tab-selected">
                    <span class="search-tab-prefix-left"><img class='img_base img_transparent_16_16' src='/static/app/images/1x1.gif' border='0' title='Transparent 16 16' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><span><em><span>All Kinds</span></em></span></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type&amp;k=c"><span>Class</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_jdt_obj16_int_obj' src='/static/app/images/1x1.gif' border='0' title='Interface' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type&amp;k=i"><span>Interface</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_jdt_obj16_enum_obj' src='/static/app/images/1x1.gif' border='0' title='Enum' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type&amp;k=e"><span>Enum</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_jdt_obj16_annotation_obj' src='/static/app/images/1x1.gif' border='0' title='Annotation' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type&amp;k=a"><span>Annotation</span></a></span>
                </div>
            </div><div class="search-tabs-left">
                <div class="search-tab-selected">
                    <span class="search-tab-prefix-left"><img class='img_base img_java' src='/static/app/images/1x1.gif' border='0' title='Java' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><span><em><span>JRE Profile</span></em></span></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_google_appengine' src='/static/app/images/1x1.gif' border='0' title='Google App Engine' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type&amp;pr=gae"><span>Google AppEngine</span></a></span>
                </div>
            </div>
        </div>
        
        
            <div class="search-results-adsense-panel">
                <script>document.write(get160x600Ad());</script>
            </div>
        
        <div class="search-tabs-right-panel">
            <div class="search-tabs-top">
                <div class="search-tab-selected">
                    <span class="search-tab-prefix-top"></span>
                    <span class="search-tab-name-top"
                        ><span><em><span>Types</span></em></span></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-top"></span>
                    <span class="search-tab-name-top"
                        ><a href="../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=project"><span>Projects</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-top"></span>
                    <span class="search-tab-name-top"
                        ><a href="../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=method"><span>Methods</span></a></span>
                </div>
            </div>
            <div class="search-result">
                <div class="search-results-hint">Unknown identifier: &quot;org/pentaho/libformula/ui/editor/FormulaMessage.java&quot;. Falling back to search</div>
                <div class="search-results-container">
    <div class="search-results-unpacked">
    <span id="entity-name-field" style="display:none;">type</span>
    <span id="icon-project" style="display:none;"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img></span>

    
    <div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_int_obj' src='/static/app/images/1x1.gif' border='0' title='Interface' width='16' height='16'></img></div>
            <span class="entity-name">org.jdal.ui.Editor</span>
            
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.0.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> jdal-core</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.jdal/jdal-core/2.0.0/org/jdal/ui/Editor.java#Editor" title="Maven-Central / org.jdal / jdal-core"><span>2.0.0</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.0.0.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_int_obj' src='/static/app/images/1x1.gif' border='0' title='Interface' width='16' height='16'></img></div>
            <span class="entity-name">org.whizu.ui.Editor</span>
            
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.1.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> whizu-core</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.whizu/whizu-core/0.0.3/org/whizu/ui/Editor.java#Editor" title="Maven-Central / org.whizu / whizu-core"><span>0.0.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.whizu/whizu-core/0.0.2/org/whizu/ui/Editor.java#Editor" title="Maven-Central / org.whizu / whizu-core"><span>0.0.2</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.0.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.apache.wiki.ui.Editor</span>
            <span class="container-details"> - Describes an editor</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.2.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> jspwiki-war</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apache.jspwiki/jspwiki-war/2.10.1/org/apache/wiki/ui/Editor.java#Editor" title="Maven-Central / org.apache.jspwiki / jspwiki-war"><span>2.10.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apache.jspwiki/jspwiki-war/2.10.0/org/apache/wiki/ui/Editor.java#Editor" title="Maven-Central / org.apache.jspwiki / jspwiki-war"><span>2.10.0</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.2.0.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.openformula.ui.LibFormulaEditorBoot</span>
            
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.3.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> libformula-ui</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.2.5/org/pentaho/openformula/ui/LibFormulaEditorBoot.java#LibFormulaEditorBoot" title="Pentaho / pentaho-library / libformula-ui"><span>1.2.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.2.3/org/pentaho/openformula/ui/LibFormulaEditorBoot.java#LibFormulaEditorBoot" title="Pentaho / pentaho-library / libformula-ui"><span>1.2.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.2.1/org/pentaho/openformula/ui/LibFormulaEditorBoot.java#LibFormulaEditorBoot" title="Pentaho / pentaho-library / libformula-ui"><span>1.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.2-SNAPSHOT/org/pentaho/openformula/ui/LibFormulaEditorBoot.java#LibFormulaEditorBoot" title="Pentaho / pentaho-library / libformula-ui"><span>1.2-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.1.6/org/pentaho/openformula/ui/LibFormulaEditorBoot.java#LibFormulaEditorBoot" title="Pentaho / pentaho-library / libformula-ui"><span>1.1.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.1.4/org/pentaho/openformula/ui/LibFormulaEditorBoot.java#LibFormulaEditorBoot" title="Pentaho / pentaho-library / libformula-ui"><span>1.1.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.1.2/org/pentaho/openformula/ui/LibFormulaEditorBoot.java#LibFormulaEditorBoot" title="Pentaho / pentaho-library / libformula-ui"><span>1.1.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.1.0/org/pentaho/openformula/ui/LibFormulaEditorBoot.java#LibFormulaEditorBoot" title="Pentaho / pentaho-library / libformula-ui"><span>1.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.0-SNAPSHOT/org/pentaho/openformula/ui/LibFormulaEditorBoot.java#LibFormulaEditorBoot" title="Pentaho / pentaho-library / libformula-ui"><span>1.0-SNAPSHOT</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.3.0.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.openformula.ui.LibFormulaEditorInfo</span>
            
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.4.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> libformula-ui</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.2.5/org/pentaho/openformula/ui/LibFormulaEditorInfo.java#LibFormulaEditorInfo" title="Pentaho / pentaho-library / libformula-ui"><span>1.2.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.2.3/org/pentaho/openformula/ui/LibFormulaEditorInfo.java#LibFormulaEditorInfo" title="Pentaho / pentaho-library / libformula-ui"><span>1.2.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.2.1/org/pentaho/openformula/ui/LibFormulaEditorInfo.java#LibFormulaEditorInfo" title="Pentaho / pentaho-library / libformula-ui"><span>1.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.2-SNAPSHOT/org/pentaho/openformula/ui/LibFormulaEditorInfo.java#LibFormulaEditorInfo" title="Pentaho / pentaho-library / libformula-ui"><span>1.2-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.1.6/org/pentaho/openformula/ui/LibFormulaEditorInfo.java#LibFormulaEditorInfo" title="Pentaho / pentaho-library / libformula-ui"><span>1.1.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.1.4/org/pentaho/openformula/ui/LibFormulaEditorInfo.java#LibFormulaEditorInfo" title="Pentaho / pentaho-library / libformula-ui"><span>1.1.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.1.2/org/pentaho/openformula/ui/LibFormulaEditorInfo.java#LibFormulaEditorInfo" title="Pentaho / pentaho-library / libformula-ui"><span>1.1.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.1.0/org/pentaho/openformula/ui/LibFormulaEditorInfo.java#LibFormulaEditorInfo" title="Pentaho / pentaho-library / libformula-ui"><span>1.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.0-SNAPSHOT/org/pentaho/openformula/ui/LibFormulaEditorInfo.java#LibFormulaEditorInfo" title="Pentaho / pentaho-library / libformula-ui"><span>1.0-SNAPSHOT</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.4.0.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.pms.ui.MetaEditor</span>
            
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.5.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-metadata-editor</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata-editor/5.1.preview.506/org/pentaho/pms/ui/MetaEditor.java#MetaEditor" title="Pentaho / pentaho / pentaho-metadata-editor"><span>5.1.preview.506</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata-editor/5.1-SNAPSHOT/org/pentaho/pms/ui/MetaEditor.java#MetaEditor" title="Pentaho / pentaho / pentaho-metadata-editor"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata-editor/5.0.6/org/pentaho/pms/ui/MetaEditor.java#MetaEditor" title="Pentaho / pentaho / pentaho-metadata-editor"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata-editor/5.0.4/org/pentaho/pms/ui/MetaEditor.java#MetaEditor" title="Pentaho / pentaho / pentaho-metadata-editor"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata-editor/5.0.2/org/pentaho/pms/ui/MetaEditor.java#MetaEditor" title="Pentaho / pentaho / pentaho-metadata-editor"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata-editor/5.0.1/org/pentaho/pms/ui/MetaEditor.java#MetaEditor" title="Pentaho / pentaho / pentaho-metadata-editor"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata-editor/5.0.0/org/pentaho/pms/ui/MetaEditor.java#MetaEditor" title="Pentaho / pentaho / pentaho-metadata-editor"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata-editor/5.0-RC5/org/pentaho/pms/ui/MetaEditor.java#MetaEditor" title="Pentaho / pentaho / pentaho-metadata-editor"><span>5.0-RC5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata-editor/5.0-RC3/org/pentaho/pms/ui/MetaEditor.java#MetaEditor" title="Pentaho / pentaho / pentaho-metadata-editor"><span>5.0-RC3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata-editor/4.5.1-SNAPSHOT/org/pentaho/pms/ui/MetaEditor.java#MetaEditor" title="Pentaho / pentaho / pentaho-metadata-editor"><span>4.5.1-SNAPSHOT</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.5.0.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.codehaus.janino.Java</span>
            <span class="container-details"> - This wrapper class defines classes that represent the elements of the Java&amp;trade; programming language</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.6.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> janino</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.codehaus.janino/janino/2.7.8/org/codehaus/janino/Java.java#Java" title="Maven-Central / org.codehaus.janino / janino"><span>2.7.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.codehaus.janino/janino/2.7.7/org/codehaus/janino/Java.java#Java" title="Maven-Central / org.codehaus.janino / janino"><span>2.7.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.codehaus.janino/janino/2.7.6/org/codehaus/janino/Java.java#Java" title="Maven-Central / org.codehaus.janino / janino"><span>2.7.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.codehaus.janino/janino/2.7.5/org/codehaus/janino/Java.java#Java" title="Maven-Central / org.codehaus.janino / janino"><span>2.7.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.codehaus.janino/janino/2.7.4/org/codehaus/janino/Java.java#Java" title="Maven-Central / org.codehaus.janino / janino"><span>2.7.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.codehaus.janino/janino/2.6.1/org/codehaus/janino/Java.java#Java" title="Maven-Central / org.codehaus.janino / janino"><span>2.6.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.codehaus.janino/janino/2.5.16/org/codehaus/janino/Java.java#Java" title="Maven-Central / org.codehaus.janino / janino"><span>2.5.16</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.codehaus.janino/janino/2.5.15/org/codehaus/janino/Java.java#Java" title="Maven-Central / org.codehaus.janino / janino"><span>2.5.15</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.6.0.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.netbeans.modules.print.ui.Editor</span>
            
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.7.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> org-netbeans-modules-print</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE80-BETA/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE80-BETA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE80/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE80</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE74-BETA/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE74-BETA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE74/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE74</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE731/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE731</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE73-BETA2/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE73-BETA2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE73-BETA/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE73-BETA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE73/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE73</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE721/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE721</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE72/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE72</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE712/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE712</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE711/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE711</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE71/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE71</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE701/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE701</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE70/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE70</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE65/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE65</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.7.0.1">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> org-netbeans-modules-print</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE80-BETA/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE80-BETA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE80/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE80</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE74-BETA/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE74-BETA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE74/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE74</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE731/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE731</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE73-BETA2/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE73-BETA2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE73-BETA/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE73-BETA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE73/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE73</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE721/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE721</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE72/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE72</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE712/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE712</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE711/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE711</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE71/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE71</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE701/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE701</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE70/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE70</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE691/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE691</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE68/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE68</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE67/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE67</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/bits.netbeans.org/maven2/org.netbeans.api/org-netbeans-modules-print/RELEASE65/org/netbeans/modules/print/ui/Editor.java#Editor" title="NetBeans / org.netbeans.api / org-netbeans-modules-print"><span>RELEASE65</span></a>
                </div>
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.eclipse.jdt.internal.ui.javaeditor.JavaEditor</span>
            <span class="container-details"> - Java specific text editor</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.8.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> ui</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.grepcode.com/java/eclipse.org/4.4.2/org.eclipse.jdt/ui/3.10.2/org/eclipse/jdt/internal/ui/javaeditor/JavaEditor.java#JavaEditor" title="Eclipse-4.4.2 / org.eclipse.jdt / ui"><span>3.10.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.grepcode.com/java/eclipse.org/4.4.1/org.eclipse.jdt/ui/3.10.1/org/eclipse/jdt/internal/ui/javaeditor/JavaEditor.java#JavaEditor" title="Eclipse-4.4.1 / org.eclipse.jdt / ui"><span>3.10.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.grepcode.com/java/eclipse.org/4.4.0/org.eclipse.jdt/ui/3.10.0/org/eclipse/jdt/internal/ui/javaeditor/JavaEditor.java#JavaEditor" title="Eclipse-4.4.0 / org.eclipse.jdt / ui"><span>3.10.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.grepcode.com/java/eclipse.org/4.3.1/org.eclipse.jdt/ui/3.9.1/org/eclipse/jdt/internal/ui/javaeditor/JavaEditor.java#JavaEditor" title="Eclipse-4.3.1 / org.eclipse.jdt / ui"><span>3.9.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.grepcode.com/java/eclipse.org/4.3/org.eclipse.jdt/ui/3.9.0/org/eclipse/jdt/internal/ui/javaeditor/JavaEditor.java#JavaEditor" title="Eclipse-4.3 / org.eclipse.jdt / ui"><span>3.9.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.grepcode.com/java/eclipse.org/4.2.2/org.eclipse.jdt/ui/3.8.2/org/eclipse/jdt/internal/ui/javaeditor/JavaEditor.java#JavaEditor" title="Eclipse-4.2.2 / org.eclipse.jdt / ui"><span>3.8.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.grepcode.com/java/eclipse.org/4.2/org.eclipse.jdt/ui/3.8.0/org/eclipse/jdt/internal/ui/javaeditor/JavaEditor.java#JavaEditor" title="Eclipse-4.2 / org.eclipse.jdt / ui"><span>3.8.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.grepcode.com/java/eclipse.org/3.7.2/org.eclipse.jdt/ui/3.7.2/org/eclipse/jdt/internal/ui/javaeditor/JavaEditor.java#JavaEditor" title="Eclipse-3.7.2 / org.eclipse.jdt / ui"><span>3.7.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.grepcode.com/java/eclipse.org/3.6.2/org.eclipse.jdt/ui/3.6.2/org/eclipse/jdt/internal/ui/javaeditor/JavaEditor.java#JavaEditor" title="Eclipse-3.6.2 / org.eclipse.jdt / ui"><span>3.6.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.grepcode.com/java/eclipse.org/3.5.2/org.eclipse.jdt/ui/3.5.2/org/eclipse/jdt/internal/ui/javaeditor/JavaEditor.java#JavaEditor" title="Eclipse-3.5.2 / org.eclipse.jdt / ui"><span>3.5.2</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.8.0.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.openformula.ui.FormulaEditorDialog</span>
            
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.9.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> libformula-ui</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.2.5/org/pentaho/openformula/ui/FormulaEditorDialog.java#FormulaEditorDialog" title="Pentaho / pentaho-library / libformula-ui"><span>1.2.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.2.3/org/pentaho/openformula/ui/FormulaEditorDialog.java#FormulaEditorDialog" title="Pentaho / pentaho-library / libformula-ui"><span>1.2.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.2.1/org/pentaho/openformula/ui/FormulaEditorDialog.java#FormulaEditorDialog" title="Pentaho / pentaho-library / libformula-ui"><span>1.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.2-SNAPSHOT/org/pentaho/openformula/ui/FormulaEditorDialog.java#FormulaEditorDialog" title="Pentaho / pentaho-library / libformula-ui"><span>1.2-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.1.6/org/pentaho/openformula/ui/FormulaEditorDialog.java#FormulaEditorDialog" title="Pentaho / pentaho-library / libformula-ui"><span>1.1.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.1.4/org/pentaho/openformula/ui/FormulaEditorDialog.java#FormulaEditorDialog" title="Pentaho / pentaho-library / libformula-ui"><span>1.1.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.1.2/org/pentaho/openformula/ui/FormulaEditorDialog.java#FormulaEditorDialog" title="Pentaho / pentaho-library / libformula-ui"><span>1.1.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.1.0/org/pentaho/openformula/ui/FormulaEditorDialog.java#FormulaEditorDialog" title="Pentaho / pentaho-library / libformula-ui"><span>1.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-ui/1.0-SNAPSHOT/org/pentaho/openformula/ui/FormulaEditorDialog.java#FormulaEditorDialog" title="Pentaho / pentaho-library / libformula-ui"><span>1.0-SNAPSHOT</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.0.1">
                
            </div>
        </div>
    </div>
    

    <script type="text/javascript">
    function setEntityInput() {
        var eName = document.getElementById('entity-name-field').innerHTML;
        var eNameInput = document.getElementById('search-entity');

        if (eNameInput) {
            eNameInput.value = eName;
        }
    }
    YAHOO.util.Event.onDOMReady(setEntityInput, null, true);

    var CONTAINER_GROUP = "container-group";
    var CONTAINER_GROUP_HIDDEN = "container-group-hidden";

    function drawExpandLinks() {
        var moreGroupsIcon = document.getElementById("icon-project").innerHTML;

        for (var x=0; document.getElementById(getVersionGroupId(x, 0, 0)) != null; x++) {
            var moreGroupsLinkEl = null;

            for (var y=0;;y++) {
                var containerGroupElBrief = document.getElementById(getVersionGroupId(x, y, 0));
                if (containerGroupElBrief == null) {
                    break;
                }

                var containerGroupElAll = document.getElementById(getVersionGroupId(x, y, 1));
                if (containerGroupElAll != null && containerGroupElAll.innerHTML.match(/\S/)) {
                    var countHiddenVersions = containerGroupElAll.childNodes.length - containerGroupElBrief.childNodes.length;

                    containerGroupElBrief.innerHTML +=
                        "<div class='result-list'>" +
                        createClickableLink("...", countHiddenVersions+" more version(s)", "container-name", "activateVersionGroup("+x+","+y+",1)") +
                        "</div>";
                }
                
                if ((getClassAttribute(containerGroupElBrief) == CONTAINER_GROUP_HIDDEN)
                    && (moreGroupsLinkEl == null)) {
                    // was over visible limit
                    var hiddenGroupCount = 1 /*this*/ + countHiddenGroups(x, y+1) /*remaining*/;

                    moreGroupsLinkEl = document.createElement("div");
                    setClassAttribute(moreGroupsLinkEl, CONTAINER_GROUP);
                    moreGroupsLinkEl.innerHTML = moreGroupsIcon+"&nbsp;"+createClickableLink("...", hiddenGroupCount+" more project(s)", "container-name", "activateProjectGroups(this.parentNode)");
                    containerGroupElBrief.parentNode.insertBefore(moreGroupsLinkEl, containerGroupElBrief);
                }
            }
        }
    }
    YAHOO.util.Event.onDOMReady(drawExpandLinks, null, true);

    function countHiddenGroups(x, y) {
        var i;
        for (i=0; document.getElementById(getVersionGroupId(x, y+i, 0)) != null; i++) { }
        return i;
    }

    function activateVersionGroup(x, y, z) {
        // hide previous
        setClassAttribute(document.getElementById(getVersionGroupId(x,y,z-1)), CONTAINER_GROUP_HIDDEN);
        // show this
        setClassAttribute(document.getElementById(getVersionGroupId(x,y,z)), CONTAINER_GROUP);
    }

    function getVersionGroupId(x, y, z) {
        return CONTAINER_GROUP+"."+x+"."+y+"."+z;
    }

    function activateProjectGroups(node) {
        var following = false;
        var ch = node.parentNode.childNodes;
        for (var i=0, ln=ch.length; i<ln; i++) {
            var c = ch.item(i);
            if (following) {
                if (/\.0$/.test(c.id)) {
                    setClassAttribute(c, CONTAINER_GROUP);
                }
            }
            else if (c == node) {
                following = true;
            }
        }
        // hide link
        setClassAttribute(node, CONTAINER_GROUP_HIDDEN);
    }

    function createClickableLink(linkText, linkTitle, linkClass, onClickFunc) {
        var onClickHandler = "this.blur();"+onClickFunc+";return false;";
        return "<a class='"+linkClass+"' title='"+linkTitle+"' href='#' onclick='"+onClickHandler+"'>"+linkText+"</a>";
    }

    </script>
</div>
</div>

                <div class="search-tabs-bottom">
                    <div class="search-tab-unselected">
                        <span class="search-tab-prefix-bottom"></span>
                        <span class="search-tab-name-bottom"
                            ><a href="../../../../../../../../../../../../../../search/?start=10&amp;query=org+pentaho+libformula+ui+editor+FormulaMessage.java&amp;entity=type"><span>Next</span></a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div>
    <div id="context-menu-panel" class='context-menu-panel' style='visibility: hidden;'></div>
    <div id="context-menu-panel-data" style='visibility: hidden;'></div>
</div>


        
        
            <div id="notification-bar">
                <table width="100%" border="0">
                    <tr valign="middle">
                        <td valign="middle"><span class="message">New to GrepCode? Check out our <a href="/faq" onclick="disableNotification(); return true;">FAQ</a></span></td>
                        <td valign="middle"><span class="cancel"><a href="#" onclick="disableNotification(); return false;">X</a></span></td>
                    </tr>
                </table>
            </div>
            <script type="text/javascript">
                YAHOO.util.Event.onDOMReady(doNotification);
            </script>
        
        
        

        

        

        
        
            <script type="text/javascript">
            try {
                pageTracker._trackPageview();
            } catch(err) {
            }
            </script>
        

        
        

        
    </body>
</html>
