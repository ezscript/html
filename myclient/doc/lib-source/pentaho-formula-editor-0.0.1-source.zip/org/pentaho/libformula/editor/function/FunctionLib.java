<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html id="html">
    <head>
        <title>org pentaho libformula editor function FunctionLib.java - GrepCode.com - Java Source Code Search 2.0</title>
        <meta name="verify-v1" content="oDbHfknRLVnvs+1b/O61iSxPEhVr3O08Fd3QqJ1cGh8="/>
        <meta name="verify-v1" content="d2G+nnw2Xr6jBfde7yNvdZirW9Y6K0fa+56zhEmm6YA="/>
        <meta name="msvalidate.01" content="62B5A32F828BC27E3852FB825A5156E4" />
        
        <meta property="fb:app_id" content="143989634057"/>
        
        <link rel="search" type="application/opensearchdescription+xml" title="grepcode.com" href="/static/app/grepcodeosd.xml"/>
        <link rel="icon" type="image/x-icon" href="/static/app/images/favicon.ico"/>

        <link href="/static/app/stylesheet/site.css" rel="stylesheet" type="text/css"/>
        <link href="/static/app/stylesheet/images-sprite.css" rel="stylesheet" type="text/css"/>
        <link href="/static/app/stylesheet/images-site-sprite.css" rel="stylesheet" type="text/css"/>

        <!-- always need these -->
        <script type="text/javascript" src="/static/app/javascript/always.js"></script>

        
        

        
        
            <script type="text/javascript" src="/static/app/javascript/grepcode.js"></script>
        

        
        
    </head>

    <body>
        <div id="header">
            <div class="head-search">
                <div class="head-outer">
                    <div class="head-middle">
                        <div class="head-inner">
                            <div>
    <div class="search-panel">
        <form action="/search">
            <span id="query-container">
                <input id="search-field" type="text" name="query" value="org pentaho libformula editor function FunctionLib.java"/>
            </span>
            <input type="hidden" name="start" value="0"></input><input type="hidden" name="entity" value="type"></input><input type="hidden" name="n" value=""></input>
            <input type="submit" value="Search"/>
            <span id="search-field-focus-flag" style="display:none;">false</span>
        </form>
    </div>
    <script>
    YAHOO.util.Event.onDOMReady(function() {
        var flag = document.getElementById("search-field-focus-flag");
        if (flag && flag.innerHTML === 'true') {
            document.getElementById("search-field").focus();
        }
    }, null, true)
    </script>
</div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="logo">
                <div class="head-outer">
                    <div class="head-middle">
                        <div class="head-inner">
                            <a href="/"><img src="/static/app/images/logo-rel.gif" alt="Logo" width="200" height="50"/></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="head-menu head-menu-width">
                <div class="head-outer">
                    <div class="head-middle">
                        <div class="head-inner">
                            <span>
			                <a href="/?st=true">Stack Trace Search</a> |
                            </span>
                            <span>
                            <a href="/eclipse">Eclipse</a> |
                            <a href="/intellij">IntelliJ</a> |
                            <a href="/contact">Contact</a> |
                            <a href="/faq">FAQ</a>
                            </span>
                            
                            <span>
                            |
                            <a href="http://blog.grepcode.com/" rel="nofollow"><img title="Our Blog" alt="Blog" src="/static/app/images/site/blog.png" width="16" height="16" border="0"/></a>
                            <a href="http://twitter.com/grepcode/" rel="nofollow"><img title="Follow us on Twitter" alt="Twitter" src="/static/app/images/site/twitter.png" width="16" height="16" border="0"/></a>
                            <a href="http://www.facebook.com/pages/GrepCode/159698964349" rel="nofollow"><img title="Follow us on FaceBook" alt="FaceBook" src="/static/app/images/site/facebook.png" width="16" height="16" border="0"/></a>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
            <script type="text/javascript">
                    var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
                    document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
            </script>
            <script type="text/javascript">
                var pageTracker = _gat._getTracker("UA-7614624-1");
            </script>
        
        
            <script>
                function isGCEnterpriseEdition() {
                    return false;
                }
            </script>
        
        
    <div class="search-tabs">
        <div class="search-tabs-left-panel">
            <div class="search-tabs-left">
                <div class="search-tab-selected">
                    <span class="search-tab-prefix-left"><img class='img_base img_transparent_16_16' src='/static/app/images/1x1.gif' border='0' title='Transparent 16 16' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><span><em><span>All Repositories</span></em></span></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_java' src='/static/app/images/1x1.gif' border='0' title='Java' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$root&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>JDK</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_apache' src='/static/app/images/1x1.gif' border='0' title='Apache' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repo1.maven.org$maven2&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Maven-Central</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_cloudera' src='/static/app/images/1x1.gif' border='0' title='Cloudera' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.cloudera.com$content$repositories$releases&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Cloudera</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_apache' src='/static/app/images/1x1.gif' border='0' title='Apache' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=obelix.ics.uci.edu$nexus$content$groups$hyracks-public-releases&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Hyracks</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_java' src='/static/app/images/1x1.gif' border='0' title='Java' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=maven.java.net$content$groups$promoted&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Java.net</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_jboss' src='/static/app/images/1x1.gif' border='0' title='Jboss' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.jboss.org$nexus$content$repositories$releases&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>JBoss</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_netbeans' src='/static/app/images/1x1.gif' border='0' title='Netbeans' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=bits.netbeans.org$maven2&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>NetBeans</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_pentaho' src='/static/app/images/1x1.gif' border='0' title='Pentaho' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.pentaho.org$artifactory$pentaho&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Pentaho</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_primefaces' src='/static/app/images/1x1.gif' border='0' title='Primefaces' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.primefaces.org&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>PrimeFaces</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_springsource' src='/static/app/images/1x1.gif' border='0' title='Springsource' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.springsource.com&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>SpringSource</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.4.2&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Eclipse-4.4.2</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.4.1&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Eclipse-4.4.1</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.4.0&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Eclipse-4.4.0</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.3.1&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Eclipse-4.3.1</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.3&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Eclipse-4.3</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.2.2&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Eclipse-4.2.2</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.2&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Eclipse-4.2</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$3.7.2&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Eclipse-3.7.2</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$3.6.2&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Eclipse-3.6.2</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=build.eclipse.org$rt$virgo$ivy$bundles$release&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Eclipse-Virgo</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=maven.glassfish.org$content$repositories$eclipselink&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>EclipseLink</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_grepcode' src='/static/app/images/1x1.gif' border='0' title='Grepcode' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$ext&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>GrepCode</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_grepcode' src='/static/app/images/1x1.gif' border='0' title='Grepcode' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$ext-eclipse&amp;start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>GrepCode-Eclipse</span></a></span>
                </div>
            </div><div class="search-tabs-left">
                <div class="search-tab-selected">
                    <span class="search-tab-prefix-left"><img class='img_base img_transparent_16_16' src='/static/app/images/1x1.gif' border='0' title='Transparent 16 16' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><span><em><span>All Kinds</span></em></span></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type&amp;k=c"><span>Class</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_jdt_obj16_int_obj' src='/static/app/images/1x1.gif' border='0' title='Interface' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type&amp;k=i"><span>Interface</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_jdt_obj16_enum_obj' src='/static/app/images/1x1.gif' border='0' title='Enum' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type&amp;k=e"><span>Enum</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_jdt_obj16_annotation_obj' src='/static/app/images/1x1.gif' border='0' title='Annotation' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type&amp;k=a"><span>Annotation</span></a></span>
                </div>
            </div><div class="search-tabs-left">
                <div class="search-tab-selected">
                    <span class="search-tab-prefix-left"><img class='img_base img_java' src='/static/app/images/1x1.gif' border='0' title='Java' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><span><em><span>JRE Profile</span></em></span></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_google_appengine' src='/static/app/images/1x1.gif' border='0' title='Google App Engine' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type&amp;pr=gae"><span>Google AppEngine</span></a></span>
                </div>
            </div>
        </div>
        
        
            <div class="search-results-adsense-panel">
                <script>document.write(get160x600Ad());</script>
            </div>
        
        <div class="search-tabs-right-panel">
            <div class="search-tabs-top">
                <div class="search-tab-selected">
                    <span class="search-tab-prefix-top"></span>
                    <span class="search-tab-name-top"
                        ><span><em><span>Types</span></em></span></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-top"></span>
                    <span class="search-tab-name-top"
                        ><a href="../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=project"><span>Projects</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-top"></span>
                    <span class="search-tab-name-top"
                        ><a href="../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=method"><span>Methods</span></a></span>
                </div>
            </div>
            <div class="search-result">
                <div class="search-results-hint">Unknown identifier: &quot;org/pentaho/libformula/editor/function/FunctionLib.java&quot;. Falling back to search</div>
                <div class="search-results-container">
    <div class="search-results-unpacked">
    <span id="entity-name-field" style="display:none;">type</span>
    <span id="icon-project" style="display:none;"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img></span>

    
    <div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_int_obj' src='/static/app/images/1x1.gif' border='0' title='Interface' width='16' height='16'></img></div>
            <span class="entity-name">java.util.function.Function</span>
            <span class="container-details"> - Represents a function that accepts one argument and produces a result</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.0.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> openjdk</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/8u40-b25/java/util/function/Function.java#Function" title="JDK / jdk / openjdk"><span>8u40-b25</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/8-b132/java/util/function/Function.java#Function" title="JDK / jdk / openjdk"><span>8-b132</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.0.0.1">
                
            </div><div class="container-group" id="container-group.0.1.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> dragome-js-jre</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.dragome/dragome-js-jre/0.96-beta2/java/util/function/Function.java#Function" title="Maven-Central / com.dragome / dragome-js-jre"><span>0.96-beta2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.dragome/dragome-js-jre/0.95.5-beta1/java/util/function/Function.java#Function" title="Maven-Central / com.dragome / dragome-js-jre"><span>0.95.5-beta1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.dragome/dragome-js-jre/0.95.2-beta1/java/util/function/Function.java#Function" title="Maven-Central / com.dragome / dragome-js-jre"><span>0.95.2-beta1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.dragome/dragome-js-jre/0.95.1-beta1/java/util/function/Function.java#Function" title="Maven-Central / com.dragome / dragome-js-jre"><span>0.95.1-beta1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.dragome/dragome-js-jre/0.95-beta1/java/util/function/Function.java#Function" title="Maven-Central / com.dragome / dragome-js-jre"><span>0.95-beta1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.0.1.1">
                
            </div><div class="container-group" id="container-group.0.2.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> mmm-util-backport-java.util.function</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/net.sf.m-m-m/mmm-util-backport-java.util.function/1.0.1/java/util/function/Function.java#Function" title="Maven-Central / net.sf.m-m-m / mmm-util-backport-java.util.function"><span>1.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/net.sf.m-m-m/mmm-util-backport-java.util.function/1.0.0/java/util/function/Function.java#Function" title="Maven-Central / net.sf.m-m-m / mmm-util-backport-java.util.function"><span>1.0.0</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.0.2.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_int_obj' src='/static/app/images/1x1.gif' border='0' title='Interface' width='16' height='16'></img></div>
            <span class="entity-name">org.mozilla.javascript.Function</span>
            <span class="container-details"> - This is interface that all functions in JavaScript must implement</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.1.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> rhino</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.mozilla/rhino/1.7.7/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.mozilla / rhino"><span>1.7.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.mozilla/rhino/1.7.6/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.mozilla / rhino"><span>1.7.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.mozilla/rhino/1.7R5/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.mozilla / rhino"><span>1.7R5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.mozilla/rhino/1.7R4/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.mozilla / rhino"><span>1.7R4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.mozilla/rhino/1.7R3/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.mozilla / rhino"><span>1.7R3</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.0.1">
                
            </div><div class="container-group" id="container-group.1.1.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> htmlunit-core-js</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.jvnet.hudson/htmlunit-core-js/2.2-hudson-2/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.jvnet.hudson / htmlunit-core-js"><span>2.2-hudson-2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.jvnet.hudson/htmlunit-core-js/2.2-hudson-1/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.jvnet.hudson / htmlunit-core-js"><span>2.2-hudson-1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.1.1">
                
            </div><div class="container-group" id="container-group.1.2.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> js</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/rhino/js/1.7R2/org/mozilla/javascript/Function.java#Function" title="Maven-Central / rhino / js"><span>1.7R2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/rhino/js/1.7R1/org/mozilla/javascript/Function.java#Function" title="Maven-Central / rhino / js"><span>1.7R1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/rhino/js/1.6R6-candidate2/org/mozilla/javascript/Function.java#Function" title="Maven-Central / rhino / js"><span>1.6R6-candidate2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/rhino/js/1.6R6/org/mozilla/javascript/Function.java#Function" title="Maven-Central / rhino / js"><span>1.6R6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/rhino/js/1.6R5/org/mozilla/javascript/Function.java#Function" title="Maven-Central / rhino / js"><span>1.6R5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/rhino/js/1.5R4.1/org/mozilla/javascript/Function.java#Function" title="Maven-Central / rhino / js"><span>1.5R4.1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.2.1">
                
            </div><div class="container-group" id="container-group.1.3.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> rhino</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/io.apigee/rhino/1.7R5pre4/org/mozilla/javascript/Function.java#Function" title="Maven-Central / io.apigee / rhino"><span>1.7R5pre4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/io.apigee/rhino/1.7R5pre3/org/mozilla/javascript/Function.java#Function" title="Maven-Central / io.apigee / rhino"><span>1.7R5pre3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/io.apigee/rhino/1.7R5pre2/org/mozilla/javascript/Function.java#Function" title="Maven-Central / io.apigee / rhino"><span>1.7R5pre2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/io.apigee/rhino/1.7R5pre1/org/mozilla/javascript/Function.java#Function" title="Maven-Central / io.apigee / rhino"><span>1.7R5pre1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.3.1">
                
            </div><div class="container-group-hidden" id="container-group.1.4.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> htmlunit-core-js</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/net.sourceforge.htmlunit/htmlunit-core-js/2.4/org/mozilla/javascript/Function.java#Function" title="Maven-Central / net.sourceforge.htmlunit / htmlunit-core-js"><span>2.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/net.sourceforge.htmlunit/htmlunit-core-js/2.2/org/mozilla/javascript/Function.java#Function" title="Maven-Central / net.sourceforge.htmlunit / htmlunit-core-js"><span>2.2</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.4.1">
                
            </div><div class="container-group-hidden" id="container-group.1.5.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> rhino</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/ro.isdc.wro4j/rhino/1.7R5-20130223-1/org/mozilla/javascript/Function.java#Function" title="Maven-Central / ro.isdc.wro4j / rhino"><span>1.7R5-20130223-1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/ro.isdc.wro4j/rhino/1.7R5-20130223/org/mozilla/javascript/Function.java#Function" title="Maven-Central / ro.isdc.wro4j / rhino"><span>1.7R5-20130223</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.5.1">
                
            </div><div class="container-group-hidden" id="container-group.1.6.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> org.apache.servicemix.bundles.rhino</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apache.servicemix.bundles/org.apache.servicemix.bundles.rhino/1.7.7_1/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.apache.servicemix.bundles / org.apache.servicemix.bundles.rhino"><span>1.7.7_1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apache.servicemix.bundles/org.apache.servicemix.bundles.rhino/1.7.6_1/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.apache.servicemix.bundles / org.apache.servicemix.bundles.rhino"><span>1.7.6_1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apache.servicemix.bundles/org.apache.servicemix.bundles.rhino/1.7R5_1/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.apache.servicemix.bundles / org.apache.servicemix.bundles.rhino"><span>1.7R5_1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apache.servicemix.bundles/org.apache.servicemix.bundles.rhino/1.7R4_1/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.apache.servicemix.bundles / org.apache.servicemix.bundles.rhino"><span>1.7R4_1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apache.servicemix.bundles/org.apache.servicemix.bundles.rhino/1.7R3_1/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.apache.servicemix.bundles / org.apache.servicemix.bundles.rhino"><span>1.7R3_1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apache.servicemix.bundles/org.apache.servicemix.bundles.rhino/1.7R2_4/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.apache.servicemix.bundles / org.apache.servicemix.bundles.rhino"><span>1.7R2_4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apache.servicemix.bundles/org.apache.servicemix.bundles.rhino/1.7R2_3/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.apache.servicemix.bundles / org.apache.servicemix.bundles.rhino"><span>1.7R2_3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apache.servicemix.bundles/org.apache.servicemix.bundles.rhino/1.7R1_5/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.apache.servicemix.bundles / org.apache.servicemix.bundles.rhino"><span>1.7R1_5</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.6.1">
                
            </div><div class="container-group-hidden" id="container-group.1.7.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> rhino</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/io.ejs/rhino/1.7R5pre1/org/mozilla/javascript/Function.java#Function" title="Maven-Central / io.ejs / rhino"><span>1.7R5pre1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/io.ejs/rhino/1.7R5pre/org/mozilla/javascript/Function.java#Function" title="Maven-Central / io.ejs / rhino"><span>1.7R5pre</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.7.1">
                
            </div><div class="container-group-hidden" id="container-group.1.8.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> phobos-rhino</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.sun.phobos/phobos-rhino/0.6.2/org/mozilla/javascript/Function.java#Function" title="Maven-Central / com.sun.phobos / phobos-rhino"><span>0.6.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.sun.phobos/phobos-rhino/0.6.0/org/mozilla/javascript/Function.java#Function" title="Maven-Central / com.sun.phobos / phobos-rhino"><span>0.6.0</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.8.1">
                
            </div><div class="container-group-hidden" id="container-group.1.9.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> rhino</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.github.tntim96/rhino/1.7R5pre05/org/mozilla/javascript/Function.java#Function" title="Maven-Central / com.github.tntim96 / rhino"><span>1.7R5pre05</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.github.tntim96/rhino/1.7R5pre04/org/mozilla/javascript/Function.java#Function" title="Maven-Central / com.github.tntim96 / rhino"><span>1.7R5pre04</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.github.tntim96/rhino/1.7R5pre03/org/mozilla/javascript/Function.java#Function" title="Maven-Central / com.github.tntim96 / rhino"><span>1.7R5pre03</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.github.tntim96/rhino/1.7R5pre01/org/mozilla/javascript/Function.java#Function" title="Maven-Central / com.github.tntim96 / rhino"><span>1.7R5pre01</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.9.1">
                
            </div><div class="container-group-hidden" id="container-group.1.10.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> rhino</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.jolira/rhino/1.7.3.1/org/mozilla/javascript/Function.java#Function" title="Maven-Central / com.jolira / rhino"><span>1.7.3.1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.10.1">
                
            </div><div class="container-group-hidden" id="container-group.1.11.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> closure-compiler-rhino</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.javascript/closure-compiler-rhino/v20140508/org/mozilla/javascript/Function.java#Function" title="Maven-Central / com.google.javascript / closure-compiler-rhino"><span>v20140508</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.javascript/closure-compiler-rhino/v20140407/org/mozilla/javascript/Function.java#Function" title="Maven-Central / com.google.javascript / closure-compiler-rhino"><span>v20140407</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.11.1">
                
            </div><div class="container-group-hidden" id="container-group.1.12.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> rhino</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/rhino/rhino/1.5R4.1/org/mozilla/javascript/Function.java#Function" title="Maven-Central / rhino / rhino"><span>1.5R4.1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.12.1">
                
            </div><div class="container-group-hidden" id="container-group.1.13.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> rhino</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.jopendocument/rhino/1.7R1/org/mozilla/javascript/Function.java#Function" title="Maven-Central / org.jopendocument / rhino"><span>1.7R1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.13.1">
                
            </div><div class="container-group-hidden" id="container-group.1.14.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> phobos-glassfish-osgi</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.sun.phobos/phobos-glassfish-osgi/0.6.2/org/mozilla/javascript/Function.java#Function" title="Maven-Central / com.sun.phobos / phobos-glassfish-osgi"><span>0.6.2</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.14.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_int_obj' src='/static/app/images/1x1.gif' border='0' title='Interface' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.reporting.libraries.formula.function.Function</span>
            <span class="container-details"> - A function is an arbitary computation</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.2.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> libformula</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula/1.2.5/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula"><span>1.2.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula/1.2.3/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula"><span>1.2.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula/1.2.1/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula"><span>1.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula/1.2-SNAPSHOT/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula"><span>1.2-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula/1.1.6/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula"><span>1.1.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula/1.1.4/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula"><span>1.1.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula/1.1.2/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula"><span>1.1.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula/1.1.0/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula"><span>1.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula/1.0-SNAPSHOT/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula"><span>1.0-SNAPSHOT</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.2.0.1">
                
            </div><div class="container-group" id="container-group.2.1.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> libformula-test</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-test/5.1-SNAPSHOT/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula-test"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-test/5.0.6/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula-test"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-test/5.0.4/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula-test"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-test/5.0.2/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula-test"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-test/5.0.1/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula-test"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-test/5.0.0/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula-test"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-test/5.0-RC5/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula-test"><span>5.0-RC5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-library/libformula-test/5.0-NIGHTLY/org/pentaho/reporting/libraries/formula/function/Function.java#Function" title="Pentaho / pentaho-library / libformula-test"><span>5.0-NIGHTLY</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.2.1.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.sqlite.Function</span>
            <span class="container-details"> - Provides an interface for creating SQLite user-defined functions</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.3.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> sqlite-jdbc</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.xerial/sqlite-jdbc/3.8.11/org/sqlite/Function.java#Function" title="Maven-Central / org.xerial / sqlite-jdbc"><span>3.8.11</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.xerial/sqlite-jdbc/3.8.10.2/org/sqlite/Function.java#Function" title="Maven-Central / org.xerial / sqlite-jdbc"><span>3.8.10.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.xerial/sqlite-jdbc/3.8.10.1/org/sqlite/Function.java#Function" title="Maven-Central / org.xerial / sqlite-jdbc"><span>3.8.10.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.xerial/sqlite-jdbc/3.8.9.1/org/sqlite/Function.java#Function" title="Maven-Central / org.xerial / sqlite-jdbc"><span>3.8.9.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.xerial/sqlite-jdbc/3.8.9/org/sqlite/Function.java#Function" title="Maven-Central / org.xerial / sqlite-jdbc"><span>3.8.9</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.xerial/sqlite-jdbc/3.8.7/org/sqlite/Function.java#Function" title="Maven-Central / org.xerial / sqlite-jdbc"><span>3.8.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.xerial/sqlite-jdbc/3.8.6/org/sqlite/Function.java#Function" title="Maven-Central / org.xerial / sqlite-jdbc"><span>3.8.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.xerial/sqlite-jdbc/3.8.5-pre1/org/sqlite/Function.java#Function" title="Maven-Central / org.xerial / sqlite-jdbc"><span>3.8.5-pre1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.xerial/sqlite-jdbc/3.7.2/org/sqlite/Function.java#Function" title="Maven-Central / org.xerial / sqlite-jdbc"><span>3.7.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.xerial/sqlite-jdbc/3.6.20/org/sqlite/Function.java#Function" title="Maven-Central / org.xerial / sqlite-jdbc"><span>3.6.20</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.xerial/sqlite-jdbc/3.6.17.1/org/sqlite/Function.java#Function" title="Maven-Central / org.xerial / sqlite-jdbc"><span>3.6.17.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.xerial/sqlite-jdbc/3.6.17/org/sqlite/Function.java#Function" title="Maven-Central / org.xerial / sqlite-jdbc"><span>3.6.17</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.3.0.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_int_obj' src='/static/app/images/1x1.gif' border='0' title='Interface' width='16' height='16'></img></div>
            <span class="entity-name">java.util.function.BiFunction</span>
            <span class="container-details"> - Represents a function that accepts two arguments and produces a result</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.4.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> openjdk</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/8u40-b25/java/util/function/BiFunction.java#BiFunction" title="JDK / jdk / openjdk"><span>8u40-b25</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/8-b132/java/util/function/BiFunction.java#BiFunction" title="JDK / jdk / openjdk"><span>8-b132</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.4.0.1">
                
            </div><div class="container-group" id="container-group.4.1.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> dragome-js-jre</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.dragome/dragome-js-jre/0.96-beta2/java/util/function/BiFunction.java#BiFunction" title="Maven-Central / com.dragome / dragome-js-jre"><span>0.96-beta2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.dragome/dragome-js-jre/0.95.5-beta1/java/util/function/BiFunction.java#BiFunction" title="Maven-Central / com.dragome / dragome-js-jre"><span>0.95.5-beta1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.dragome/dragome-js-jre/0.95.2-beta1/java/util/function/BiFunction.java#BiFunction" title="Maven-Central / com.dragome / dragome-js-jre"><span>0.95.2-beta1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.dragome/dragome-js-jre/0.95.1-beta1/java/util/function/BiFunction.java#BiFunction" title="Maven-Central / com.dragome / dragome-js-jre"><span>0.95.1-beta1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.dragome/dragome-js-jre/0.95-beta1/java/util/function/BiFunction.java#BiFunction" title="Maven-Central / com.dragome / dragome-js-jre"><span>0.95-beta1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.4.1.1">
                
            </div><div class="container-group" id="container-group.4.2.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> mmm-util-backport-java.util.function</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/net.sf.m-m-m/mmm-util-backport-java.util.function/1.0.1/java/util/function/BiFunction.java#BiFunction" title="Maven-Central / net.sf.m-m-m / mmm-util-backport-java.util.function"><span>1.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repo1.maven.org/maven2/net.sf.m-m-m/mmm-util-backport-java.util.function/1.0.0/java/util/function/BiFunction.java#BiFunction" title="Maven-Central / net.sf.m-m-m / mmm-util-backport-java.util.function"><span>1.0.0</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.4.2.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.metadata.libformula.EqualsFunction</span>
            
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.5.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-metadata</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.1-SNAPSHOT/org/pentaho/metadata/libformula/EqualsFunction.java#EqualsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.6/org/pentaho/metadata/libformula/EqualsFunction.java#EqualsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.4/org/pentaho/metadata/libformula/EqualsFunction.java#EqualsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.2/org/pentaho/metadata/libformula/EqualsFunction.java#EqualsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.1/org/pentaho/metadata/libformula/EqualsFunction.java#EqualsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.0/org/pentaho/metadata/libformula/EqualsFunction.java#EqualsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.8/org/pentaho/metadata/libformula/EqualsFunction.java#EqualsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7.1/org/pentaho/metadata/libformula/EqualsFunction.java#EqualsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7/org/pentaho/metadata/libformula/EqualsFunction.java#EqualsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.6/org/pentaho/metadata/libformula/EqualsFunction.java#EqualsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5.1/org/pentaho/metadata/libformula/EqualsFunction.java#EqualsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5/org/pentaho/metadata/libformula/EqualsFunction.java#EqualsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.4/org/pentaho/metadata/libformula/EqualsFunction.java#EqualsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.4</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.5.0.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.metadata.libformula.ContainsFunction</span>
            <span class="container-details"> - This function checks to see if a substring is within a larger string and is needed for the inline ETL implementation of Pentaho Metadata</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.6.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-metadata</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.1-SNAPSHOT/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.6/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.4/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.2/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.1/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.0/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.8/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7.1/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.6/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5.1/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.4/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3.1/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.0.1/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.0.1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.6.0.1">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-metadata</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.1-SNAPSHOT/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.6/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.4/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.2/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.1/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.0/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.8/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7.1/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.6/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5.1/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.4/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3.1/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.2.1/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.2/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.1/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.3/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.2/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.0/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.2.2.1/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.2.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.2.1/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.1.0/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.0.1/org/pentaho/metadata/libformula/ContainsFunction.java#ContainsFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.0.1</span></a>
                </div>
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.metadata.libformula.InFunction</span>
            
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.7.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-metadata</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.1-SNAPSHOT/org/pentaho/metadata/libformula/InFunction.java#InFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.6/org/pentaho/metadata/libformula/InFunction.java#InFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.4/org/pentaho/metadata/libformula/InFunction.java#InFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.2/org/pentaho/metadata/libformula/InFunction.java#InFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.1/org/pentaho/metadata/libformula/InFunction.java#InFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.0/org/pentaho/metadata/libformula/InFunction.java#InFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.8/org/pentaho/metadata/libformula/InFunction.java#InFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7.1/org/pentaho/metadata/libformula/InFunction.java#InFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7/org/pentaho/metadata/libformula/InFunction.java#InFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.6/org/pentaho/metadata/libformula/InFunction.java#InFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5.1/org/pentaho/metadata/libformula/InFunction.java#InFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5/org/pentaho/metadata/libformula/InFunction.java#InFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.4/org/pentaho/metadata/libformula/InFunction.java#InFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.4</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.7.0.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.metadata.libformula.LikeFunction</span>
            <span class="container-details"> - This function is similar to the LIKE function in SQL, and is needed for the inline ETL implementation of Pentaho Metadata</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.8.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-metadata</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.1-SNAPSHOT/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.6/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.4/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.2/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.1/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.0/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.8/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7.1/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.6/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5.1/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.4/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3.1/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.0.1/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.0.1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.8.0.1">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-metadata</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.1-SNAPSHOT/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.6/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.4/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.2/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.1/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.0/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.8/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7.1/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.6/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5.1/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.4/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3.1/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.2.1/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.2/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.1/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.3/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.2/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.0/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.2.2.1/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.2.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.2.1/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.1.0/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.0.1/org/pentaho/metadata/libformula/LikeFunction.java#LikeFunction" title="Pentaho / pentaho / pentaho-metadata"><span>3.0.1</span></a>
                </div>
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_int_obj' src='/static/app/images/1x1.gif' border='0' title='Interface' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.reporting.engine.classic.core.function.Function</span>
            <span class="container-details"> - The interface for report functions</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.9.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-reporting-engine-classic-core</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.1-SNAPSHOT/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.6/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.5.1/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.5/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.4/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.3/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.2/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.1/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.0.1/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.0/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.4.5/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.4.4/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.4.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.4.2/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.4.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.4.1/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.4.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.4-GA/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.4-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.7.0-GA/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.7.0-GA</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.0.1">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-reporting-engine-classic-core</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.1-SNAPSHOT/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.6/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.5.1/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.5/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.4/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.3/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.2/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.1/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.0.1/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/5.0.0/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.4.5/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.4.4/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.4.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.4.2/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.4.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.4.1/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.4.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.4-GA/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.4-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.3.1/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.3-GA/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.3-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.2.2/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.2.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.2.1/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.2-GA/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.2-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.1.3/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.1.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.1.2/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.1.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.1.1/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.1.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.1-GA/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.1-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.0.3/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.0.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.0.2/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.9.0-GA/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.9.0-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.8.3.2/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.8.3.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.8.3-GA/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.8.3-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho-reporting-engine/pentaho-reporting-engine-classic-core/3.7.0-GA/org/pentaho/reporting/engine/classic/core/function/Function.java#Function" title="Pentaho / pentaho-reporting-engine / pentaho-reporting-engine-classic-core"><span>3.7.0-GA</span></a>
                </div>
            </div>
        </div>
    </div>
    

    <script type="text/javascript">
    function setEntityInput() {
        var eName = document.getElementById('entity-name-field').innerHTML;
        var eNameInput = document.getElementById('search-entity');

        if (eNameInput) {
            eNameInput.value = eName;
        }
    }
    YAHOO.util.Event.onDOMReady(setEntityInput, null, true);

    var CONTAINER_GROUP = "container-group";
    var CONTAINER_GROUP_HIDDEN = "container-group-hidden";

    function drawExpandLinks() {
        var moreGroupsIcon = document.getElementById("icon-project").innerHTML;

        for (var x=0; document.getElementById(getVersionGroupId(x, 0, 0)) != null; x++) {
            var moreGroupsLinkEl = null;

            for (var y=0;;y++) {
                var containerGroupElBrief = document.getElementById(getVersionGroupId(x, y, 0));
                if (containerGroupElBrief == null) {
                    break;
                }

                var containerGroupElAll = document.getElementById(getVersionGroupId(x, y, 1));
                if (containerGroupElAll != null && containerGroupElAll.innerHTML.match(/\S/)) {
                    var countHiddenVersions = containerGroupElAll.childNodes.length - containerGroupElBrief.childNodes.length;

                    containerGroupElBrief.innerHTML +=
                        "<div class='result-list'>" +
                        createClickableLink("...", countHiddenVersions+" more version(s)", "container-name", "activateVersionGroup("+x+","+y+",1)") +
                        "</div>";
                }
                
                if ((getClassAttribute(containerGroupElBrief) == CONTAINER_GROUP_HIDDEN)
                    && (moreGroupsLinkEl == null)) {
                    // was over visible limit
                    var hiddenGroupCount = 1 /*this*/ + countHiddenGroups(x, y+1) /*remaining*/;

                    moreGroupsLinkEl = document.createElement("div");
                    setClassAttribute(moreGroupsLinkEl, CONTAINER_GROUP);
                    moreGroupsLinkEl.innerHTML = moreGroupsIcon+"&nbsp;"+createClickableLink("...", hiddenGroupCount+" more project(s)", "container-name", "activateProjectGroups(this.parentNode)");
                    containerGroupElBrief.parentNode.insertBefore(moreGroupsLinkEl, containerGroupElBrief);
                }
            }
        }
    }
    YAHOO.util.Event.onDOMReady(drawExpandLinks, null, true);

    function countHiddenGroups(x, y) {
        var i;
        for (i=0; document.getElementById(getVersionGroupId(x, y+i, 0)) != null; i++) { }
        return i;
    }

    function activateVersionGroup(x, y, z) {
        // hide previous
        setClassAttribute(document.getElementById(getVersionGroupId(x,y,z-1)), CONTAINER_GROUP_HIDDEN);
        // show this
        setClassAttribute(document.getElementById(getVersionGroupId(x,y,z)), CONTAINER_GROUP);
    }

    function getVersionGroupId(x, y, z) {
        return CONTAINER_GROUP+"."+x+"."+y+"."+z;
    }

    function activateProjectGroups(node) {
        var following = false;
        var ch = node.parentNode.childNodes;
        for (var i=0, ln=ch.length; i<ln; i++) {
            var c = ch.item(i);
            if (following) {
                if (/\.0$/.test(c.id)) {
                    setClassAttribute(c, CONTAINER_GROUP);
                }
            }
            else if (c == node) {
                following = true;
            }
        }
        // hide link
        setClassAttribute(node, CONTAINER_GROUP_HIDDEN);
    }

    function createClickableLink(linkText, linkTitle, linkClass, onClickFunc) {
        var onClickHandler = "this.blur();"+onClickFunc+";return false;";
        return "<a class='"+linkClass+"' title='"+linkTitle+"' href='#' onclick='"+onClickHandler+"'>"+linkText+"</a>";
    }

    </script>
</div>
</div>

                <div class="search-tabs-bottom">
                    <div class="search-tab-unselected">
                        <span class="search-tab-prefix-bottom"></span>
                        <span class="search-tab-name-bottom"
                            ><a href="../../../../../../../../../../../../../../search/?start=10&amp;query=org+pentaho+libformula+editor+function+FunctionLib.java&amp;entity=type"><span>Next</span></a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div>
    <div id="context-menu-panel" class='context-menu-panel' style='visibility: hidden;'></div>
    <div id="context-menu-panel-data" style='visibility: hidden;'></div>
</div>


        
        
            <div id="notification-bar">
                <table width="100%" border="0">
                    <tr valign="middle">
                        <td valign="middle"><span class="message">New to GrepCode? Check out our <a href="/faq" onclick="disableNotification(); return true;">FAQ</a></span></td>
                        <td valign="middle"><span class="cancel"><a href="#" onclick="disableNotification(); return false;">X</a></span></td>
                    </tr>
                </table>
            </div>
            <script type="text/javascript">
                YAHOO.util.Event.onDOMReady(doNotification);
            </script>
        
        
        

        

        

        
        
            <script type="text/javascript">
            try {
                pageTracker._trackPageview();
            } catch(err) {
            }
            </script>
        

        
        

        
    </body>
</html>
