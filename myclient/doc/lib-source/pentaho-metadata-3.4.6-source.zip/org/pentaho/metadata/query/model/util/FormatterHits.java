<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html id="html">
    <head>
        <title>org pentaho metadata query model util FormatterHits.java - GrepCode.com - Java Source Code Search 2.0</title>
        <meta name="verify-v1" content="oDbHfknRLVnvs+1b/O61iSxPEhVr3O08Fd3QqJ1cGh8="/>
        <meta name="verify-v1" content="d2G+nnw2Xr6jBfde7yNvdZirW9Y6K0fa+56zhEmm6YA="/>
        <meta name="msvalidate.01" content="62B5A32F828BC27E3852FB825A5156E4" />
        
        <meta property="fb:app_id" content="143989634057"/>
        
        <link rel="search" type="application/opensearchdescription+xml" title="grepcode.com" href="/static/app/grepcodeosd.xml"/>
        <link rel="icon" type="image/x-icon" href="/static/app/images/favicon.ico"/>

        <link href="/static/app/stylesheet/site.css" rel="stylesheet" type="text/css"/>
        <link href="/static/app/stylesheet/images-sprite.css" rel="stylesheet" type="text/css"/>
        <link href="/static/app/stylesheet/images-site-sprite.css" rel="stylesheet" type="text/css"/>

        <!-- always need these -->
        <script type="text/javascript" src="/static/app/javascript/always.js"></script>

        
        

        
        
            <script type="text/javascript" src="/static/app/javascript/grepcode.js"></script>
        

        
        
    </head>

    <body>
        <div id="header">
            <div class="head-search">
                <div class="head-outer">
                    <div class="head-middle">
                        <div class="head-inner">
                            <div>
    <div class="search-panel">
        <form action="/search">
            <span id="query-container">
                <input id="search-field" type="text" name="query" value="org pentaho metadata query model util FormatterHits.java"/>
            </span>
            <input type="hidden" name="start" value="0"></input><input type="hidden" name="entity" value="type"></input><input type="hidden" name="n" value=""></input>
            <input type="submit" value="Search"/>
            <span id="search-field-focus-flag" style="display:none;">false</span>
        </form>
    </div>
    <script>
    YAHOO.util.Event.onDOMReady(function() {
        var flag = document.getElementById("search-field-focus-flag");
        if (flag && flag.innerHTML === 'true') {
            document.getElementById("search-field").focus();
        }
    }, null, true)
    </script>
</div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="logo">
                <div class="head-outer">
                    <div class="head-middle">
                        <div class="head-inner">
                            <a href="/"><img src="/static/app/images/logo-rel.gif" alt="Logo" width="200" height="50"/></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="head-menu head-menu-width">
                <div class="head-outer">
                    <div class="head-middle">
                        <div class="head-inner">
                            <span>
			                <a href="/?st=true">Stack Trace Search</a> |
                            </span>
                            <span>
                            <a href="/eclipse">Eclipse</a> |
                            <a href="/intellij">IntelliJ</a> |
                            <a href="/contact">Contact</a> |
                            <a href="/faq">FAQ</a>
                            </span>
                            
                            <span>
                            |
                            <a href="http://blog.grepcode.com/" rel="nofollow"><img title="Our Blog" alt="Blog" src="/static/app/images/site/blog.png" width="16" height="16" border="0"/></a>
                            <a href="http://twitter.com/grepcode/" rel="nofollow"><img title="Follow us on Twitter" alt="Twitter" src="/static/app/images/site/twitter.png" width="16" height="16" border="0"/></a>
                            <a href="http://www.facebook.com/pages/GrepCode/159698964349" rel="nofollow"><img title="Follow us on FaceBook" alt="FaceBook" src="/static/app/images/site/facebook.png" width="16" height="16" border="0"/></a>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
            <script type="text/javascript">
                    var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
                    document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
            </script>
            <script type="text/javascript">
                var pageTracker = _gat._getTracker("UA-7614624-1");
            </script>
        
        
            <script>
                function isGCEnterpriseEdition() {
                    return false;
                }
            </script>
        
        
    <div class="search-tabs">
        <div class="search-tabs-left-panel">
            <div class="search-tabs-left">
                <div class="search-tab-selected">
                    <span class="search-tab-prefix-left"><img class='img_base img_transparent_16_16' src='/static/app/images/1x1.gif' border='0' title='Transparent 16 16' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><span><em><span>All Repositories</span></em></span></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_java' src='/static/app/images/1x1.gif' border='0' title='Java' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$root&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>JDK</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_apache' src='/static/app/images/1x1.gif' border='0' title='Apache' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repo1.maven.org$maven2&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Maven-Central</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_cloudera' src='/static/app/images/1x1.gif' border='0' title='Cloudera' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.cloudera.com$content$repositories$releases&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Cloudera</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_apache' src='/static/app/images/1x1.gif' border='0' title='Apache' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=obelix.ics.uci.edu$nexus$content$groups$hyracks-public-releases&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Hyracks</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_java' src='/static/app/images/1x1.gif' border='0' title='Java' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=maven.java.net$content$groups$promoted&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Java.net</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_jboss' src='/static/app/images/1x1.gif' border='0' title='Jboss' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.jboss.org$nexus$content$repositories$releases&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>JBoss</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_netbeans' src='/static/app/images/1x1.gif' border='0' title='Netbeans' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=bits.netbeans.org$maven2&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>NetBeans</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_pentaho' src='/static/app/images/1x1.gif' border='0' title='Pentaho' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.pentaho.org$artifactory$pentaho&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Pentaho</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_primefaces' src='/static/app/images/1x1.gif' border='0' title='Primefaces' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.primefaces.org&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>PrimeFaces</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_springsource' src='/static/app/images/1x1.gif' border='0' title='Springsource' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.springsource.com&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>SpringSource</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.4.2&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Eclipse-4.4.2</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.4.1&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Eclipse-4.4.1</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.4.0&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Eclipse-4.4.0</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.3.1&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Eclipse-4.3.1</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.3&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Eclipse-4.3</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.2.2&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Eclipse-4.2.2</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$4.2&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Eclipse-4.2</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$3.7.2&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Eclipse-3.7.2</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$eclipse.org$3.6.2&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Eclipse-3.6.2</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=build.eclipse.org$rt$virgo$ivy$bundles$release&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Eclipse-Virgo</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_eclipse' src='/static/app/images/1x1.gif' border='0' title='Eclipse' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=maven.glassfish.org$content$repositories$eclipselink&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>EclipseLink</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_grepcode' src='/static/app/images/1x1.gif' border='0' title='Grepcode' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$ext&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>GrepCode</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_grepcode' src='/static/app/images/1x1.gif' border='0' title='Grepcode' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?r=repository.grepcode.com$java$ext-eclipse&amp;start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>GrepCode-Eclipse</span></a></span>
                </div>
            </div><div class="search-tabs-left">
                <div class="search-tab-selected">
                    <span class="search-tab-prefix-left"><img class='img_base img_transparent_16_16' src='/static/app/images/1x1.gif' border='0' title='Transparent 16 16' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><span><em><span>All Kinds</span></em></span></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type&amp;k=c"><span>Class</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_jdt_obj16_int_obj' src='/static/app/images/1x1.gif' border='0' title='Interface' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type&amp;k=i"><span>Interface</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_jdt_obj16_enum_obj' src='/static/app/images/1x1.gif' border='0' title='Enum' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type&amp;k=e"><span>Enum</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_jdt_obj16_annotation_obj' src='/static/app/images/1x1.gif' border='0' title='Annotation' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type&amp;k=a"><span>Annotation</span></a></span>
                </div>
            </div><div class="search-tabs-left">
                <div class="search-tab-selected">
                    <span class="search-tab-prefix-left"><img class='img_base img_java' src='/static/app/images/1x1.gif' border='0' title='Java' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><span><em><span>JRE Profile</span></em></span></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-left"><img class='img_base img_google_appengine' src='/static/app/images/1x1.gif' border='0' title='Google App Engine' width='16' height='16'></img></span>
                    <span class="search-tab-name-left"
                        ><a href="../../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type&amp;pr=gae"><span>Google AppEngine</span></a></span>
                </div>
            </div>
        </div>
        
        
            <div class="search-results-adsense-panel">
                <script>document.write(get160x600Ad());</script>
            </div>
        
        <div class="search-tabs-right-panel">
            <div class="search-tabs-top">
                <div class="search-tab-selected">
                    <span class="search-tab-prefix-top"></span>
                    <span class="search-tab-name-top"
                        ><span><em><span>Types</span></em></span></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-top"></span>
                    <span class="search-tab-name-top"
                        ><a href="../../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=project"><span>Projects</span></a></span>
                </div><div class="search-tab-unselected">
                    <span class="search-tab-prefix-top"></span>
                    <span class="search-tab-name-top"
                        ><a href="../../../../../../../../../../../../../../../search/?start=0&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=method"><span>Methods</span></a></span>
                </div>
            </div>
            <div class="search-result">
                <div class="search-results-hint">Unknown identifier: &quot;org/pentaho/metadata/query/model/util/FormatterHits.java&quot;. Falling back to search</div>
                <div class="search-results-container">
    <div class="search-results-unpacked">
    <span id="entity-name-field" style="display:none;">type</span>
    <span id="icon-project" style="display:none;"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img></span>

    
    <div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">java.util.Formatter</span>
            <span class="container-details"> - An interpreter for printf-style format strings</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.0.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> openjdk</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/8u40-b25/java/util/Formatter.java#Formatter" title="JDK / jdk / openjdk"><span>8u40-b25</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/8-b132/java/util/Formatter.java#Formatter" title="JDK / jdk / openjdk"><span>8-b132</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/7u40-b43/java/util/Formatter.java#Formatter" title="JDK / jdk / openjdk"><span>7u40-b43</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/7-b147/java/util/Formatter.java#Formatter" title="JDK / jdk / openjdk"><span>7-b147</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/6-b27/java/util/Formatter.java#Formatter" title="JDK / jdk / openjdk"><span>6-b27</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/6-b14/java/util/Formatter.java#Formatter" title="JDK / jdk / openjdk"><span>6-b14</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.0.0.1">
                
            </div><div class="container-group" id="container-group.0.1.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> robovm-rt</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.5.0/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.5.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.4.0/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.4.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.3.0/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.3.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.2.0/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.2.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.1.0/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.0.0/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.14/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.14</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.13/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.13</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.12/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.12</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.11/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.11</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.10/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.10</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.9/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.9</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.8/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.7/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.6/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.2/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.2</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.0.1.1">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> robovm-rt</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.5.0/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.5.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.4.0/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.4.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.3.0/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.3.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.2.0/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.2.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.1.0/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.0.0/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.0.0-beta-04/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.0.0-beta-04</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.0.0-beta-03/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.0.0-beta-03</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.0.0-beta-02/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.0.0-beta-02</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.0.0-beta-01/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>1.0.0-beta-01</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.14/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.14</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.13/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.13</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.12/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.12</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.11/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.11</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.10/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.10</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.9/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.9</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.8/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.7/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.6/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.5/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.4/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.3/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.2/java/util/Formatter.java#Formatter" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.2</span></a>
                </div>
            </div><div class="container-group" id="container-group.0.2.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> android-all</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robolectric/android-all/5.0.0_r2-robolectric-1/java/util/Formatter.java#Formatter" title="Maven-Central / org.robolectric / android-all"><span>5.0.0_r2-robolectric-1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robolectric/android-all/5.0.0_r2-robolectric-0/java/util/Formatter.java#Formatter" title="Maven-Central / org.robolectric / android-all"><span>5.0.0_r2-robolectric-0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robolectric/android-all/4.4_r1-robolectric-1/java/util/Formatter.java#Formatter" title="Maven-Central / org.robolectric / android-all"><span>4.4_r1-robolectric-1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.0.2.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.metadata.query.model.Query</span>
            <span class="container-details"> - The Query object defines a logical query model</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.1.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-metadata</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.1-SNAPSHOT/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.6/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.4/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.2/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.1/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.0/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.8/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7.1/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.6/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5.1/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.4/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3.1/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.0.1/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.0.1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.1.0.1">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-metadata</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.1-SNAPSHOT/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.6/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.4/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.2/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.1/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.0/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.8/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7.1/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.6/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5.1/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.4/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3.1/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.2.1/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.2/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.1/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.3/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.2/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.0/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.2.2.1/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.2.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.2.1/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.1.0/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.0.1/org/pentaho/metadata/query/model/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.0.1</span></a>
                </div>
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.metadata.model.thin.Query</span>
            <span class="container-details"> - Defines a query model in terms of metadata</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.2.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-metadata</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.1-SNAPSHOT/org/pentaho/metadata/model/thin/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.6/org/pentaho/metadata/model/thin/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.4/org/pentaho/metadata/model/thin/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.2/org/pentaho/metadata/model/thin/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.1/org/pentaho/metadata/model/thin/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.0/org/pentaho/metadata/model/thin/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.8/org/pentaho/metadata/model/thin/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7.1/org/pentaho/metadata/model/thin/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7/org/pentaho/metadata/model/thin/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.6/org/pentaho/metadata/model/thin/Query.java#Query" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.6</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.2.0.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.metadata.util.Util</span>
            
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.3.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-metadata</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.1-SNAPSHOT/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.6/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.4/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.2/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.1/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.0/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.8/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7.1/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.6/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5.1/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.4/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3.1/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.1.0/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.1.0</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.3.0.1">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-metadata</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.1-SNAPSHOT/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.6/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.4/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.2/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.1/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.0/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.8/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7.1/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.6/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5.1/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.4/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3.1/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.2.1/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.2/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.1/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.3/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.2/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.0/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.2.2.1/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.2.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.2.1/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.1.0/org/pentaho/metadata/util/Util.java#Util" title="Pentaho / pentaho / pentaho-metadata"><span>3.1.0</span></a>
                </div>
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.jbundle.model.util.Util</span>
            <span class="container-details"> - Basic utilities</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.4.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> org.jbundle.model</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.jbundle/org.jbundle.model/1.0.9/org/jbundle/model/util/Util.java#Util" title="Maven-Central / org.jbundle / org.jbundle.model"><span>1.0.9</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.jbundle/org.jbundle.model/1.0.3/org/jbundle/model/util/Util.java#Util" title="Maven-Central / org.jbundle / org.jbundle.model"><span>1.0.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.jbundle/org.jbundle.model/1.0.2/org/jbundle/model/util/Util.java#Util" title="Maven-Central / org.jbundle / org.jbundle.model"><span>1.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.jbundle/org.jbundle.model/1.0.1/org/jbundle/model/util/Util.java#Util" title="Maven-Central / org.jbundle / org.jbundle.model"><span>1.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.jbundle/org.jbundle.model/0.7.8/org/jbundle/model/util/Util.java#Util" title="Maven-Central / org.jbundle / org.jbundle.model"><span>0.7.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.jbundle/org.jbundle.model/0.7.7/org/jbundle/model/util/Util.java#Util" title="Maven-Central / org.jbundle / org.jbundle.model"><span>0.7.7</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.4.0.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.metadata.query.model.util.FormatterHits</span>
            
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.5.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-metadata</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.1-SNAPSHOT/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.6/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.4/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.2/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.1/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.0/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.8/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7.1/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.6/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5.1/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.4/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3.1/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.0/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.0</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.5.0.1">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-metadata</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.1-SNAPSHOT/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.6/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.4/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.2/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.1/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.0/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.8/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7.1/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.6/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5.1/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.5/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.4/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3.1/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.3/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.2.1/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.2/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.1/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.3/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.2/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.3.0/org/pentaho/metadata/query/model/util/CsvDataTypeEvaluator.java#FormatterHits" title="Pentaho / pentaho / pentaho-metadata"><span>3.3.0</span></a>
                </div>
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.common.ui.metadata.model.impl.Query</span>
            
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.6.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> common-ui</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/5.1-SNAPSHOT/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/5.0.6/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/5.0.3/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>5.0.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/5.0.0.1/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>5.0.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.3.3/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.3.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.3-GA/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.3-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.2.2/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.2.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.2.1/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.2-GA/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.2-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.1-SP158/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.1-SP158</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.1-GA/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.1-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.0.1/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.0-GA/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.0-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/1.0.2.2/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>1.0.2.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/1.0.1-GA/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>1.0.1-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/DOJO-SNAPSHOT/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>DOJO-SNAPSHOT</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.6.0.1">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> common-ui</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/5.1-SNAPSHOT/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/5.0.6/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/5.0.4-ENGOPS-404/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>5.0.4-ENGOPS-404</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/5.0.3/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>5.0.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/5.0.1-stable/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>5.0.1-stable</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/5.0.0.1/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>5.0.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/5.0-RC4/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>5.0-RC4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/5.0-RC2/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>5.0-RC2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/5.0-SNAPSHOT/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>5.0-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.3.3/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.3.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.3-GA/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.3-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.2.2/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.2.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.2.1/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.2-GA/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.2-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.1-SP158/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.1-SP158</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.1-GA/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.1-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.0.1/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8.0-GA/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8.0-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.8-SNAPSHOT/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.8-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/4.6-SNAPSHOT/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>4.6-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/1.0.2.2/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>1.0.2.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/1.0.2-RC1/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>1.0.2-RC1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/1.0.1-GA/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>1.0.1-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/1.0.0-GA/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>1.0.0-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/common-ui/DOJO-SNAPSHOT/org/pentaho/common/ui/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / common-ui"><span>DOJO-SNAPSHOT</span></a>
                </div>
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.platform.dataaccess.metadata.model.impl.Query</span>
            
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.7.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-bi-platform-data-access</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.1.preview.506/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.1.preview.506</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.7/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.6/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.5/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.4/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.3/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.2/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.1/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.0.1/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.0/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.8.3.5/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.8.3.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.8.3.1/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.8.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.8.3-GA/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.8.3-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.8.2-GA/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.8.2-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.8.1.1/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.8.1.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.0.0-RC1/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.0.0-RC1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.7.0.1">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-bi-platform-data-access</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.1.preview.506/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.1.preview.506</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.7/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.6/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.5/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.4/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.3/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.2/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.1/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.1-stable/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.1-stable</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.0.1/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0.0/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0-RC5/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0-RC5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0-RC4/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0-RC4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0-RC3/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0-RC3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0-RC2/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0-RC2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0-SNAPSHOT/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/5.0-NIGHTLY/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>5.0-NIGHTLY</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.8.3.5/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.8.3.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.8.3.1/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.8.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.8.3-GA/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.8.3-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.8.2-GA/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.8.2-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.8.1.1/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.8.1.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.8.1-GA/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.8.1-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.8.0-GA/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.8.0-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.8.0-stable/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.8.0-stable</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.8-SNAPSHOT/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.8-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.5.0-GA/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.5.0-GA</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access/4.0.0-RC1/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access"><span>4.0.0-RC1</span></a>
                </div>
            </div><div class="container-group" id="container-group.7.1.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-bi-platform-data-access-v2</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-bi-platform-data-access-v2/5.1-NIGHTLY/org/pentaho/platform/dataaccess/metadata/model/impl/Query.java#Query" title="Pentaho / pentaho / pentaho-bi-platform-data-access-v2"><span>5.1-NIGHTLY</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.7.1.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">org.pentaho.metadata.model.thin.Model</span>
            
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.8.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> pentaho-metadata</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.1-SNAPSHOT/org/pentaho/metadata/model/thin/Model.java#Model" title="Pentaho / pentaho / pentaho-metadata"><span>5.1-SNAPSHOT</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.6/org/pentaho/metadata/model/thin/Model.java#Model" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.4/org/pentaho/metadata/model/thin/Model.java#Model" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.2/org/pentaho/metadata/model/thin/Model.java#Model" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.1/org/pentaho/metadata/model/thin/Model.java#Model" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/5.0.0/org/pentaho/metadata/model/thin/Model.java#Model" title="Pentaho / pentaho / pentaho-metadata"><span>5.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.8/org/pentaho/metadata/model/thin/Model.java#Model" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7.1/org/pentaho/metadata/model/thin/Model.java#Model" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.7/org/pentaho/metadata/model/thin/Model.java#Model" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.pentaho.org/artifactory/pentaho/pentaho/pentaho-metadata/3.4.6/org/pentaho/metadata/model/thin/Model.java#Model" title="Pentaho / pentaho / pentaho-metadata"><span>3.4.6</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.8.0.1">
                
            </div>
        </div>
    </div><div class="search-result-item">
        <div class="search-result-item-head">
            <div class="entity-icon"><img class='img_base img_jdt_obj16_class_obj' src='/static/app/images/1x1.gif' border='0' title='Class' width='16' height='16'></img></div>
            <span class="entity-name">java.util.Arrays</span>
            <span class="container-details"> - This class contains various methods for manipulating arrays (such as sorting and searching)</span>
        </div>
        <div class="container-groups">
            <div class="container-group" id="container-group.9.0.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> openjdk</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/8u40-b25/java/util/Arrays.java#Arrays" title="JDK / jdk / openjdk"><span>8u40-b25</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/8-b132/java/util/Arrays.java#Arrays" title="JDK / jdk / openjdk"><span>8-b132</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/7u40-b43/java/util/Arrays.java#Arrays" title="JDK / jdk / openjdk"><span>7u40-b43</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/7-b147/java/util/Arrays.java#Arrays" title="JDK / jdk / openjdk"><span>7-b147</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/6-b27/java/util/Arrays.java#Arrays" title="JDK / jdk / openjdk"><span>6-b27</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repository.grepcode.com/java/root/jdk/openjdk/6-b14/java/util/Arrays.java#Arrays" title="JDK / jdk / openjdk"><span>6-b14</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.0.1">
                
            </div><div class="container-group" id="container-group.9.1.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> emul</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apidesign.bck2brwsr/emul/0.15/java/util/Arrays.java#Arrays" title="Maven-Central / org.apidesign.bck2brwsr / emul"><span>0.15</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apidesign.bck2brwsr/emul/0.14/java/util/Arrays.java#Arrays" title="Maven-Central / org.apidesign.bck2brwsr / emul"><span>0.14</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apidesign.bck2brwsr/emul/0.13/java/util/Arrays.java#Arrays" title="Maven-Central / org.apidesign.bck2brwsr / emul"><span>0.13</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apidesign.bck2brwsr/emul/0.12/java/util/Arrays.java#Arrays" title="Maven-Central / org.apidesign.bck2brwsr / emul"><span>0.12</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apidesign.bck2brwsr/emul/0.11/java/util/Arrays.java#Arrays" title="Maven-Central / org.apidesign.bck2brwsr / emul"><span>0.11</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apidesign.bck2brwsr/emul/0.10/java/util/Arrays.java#Arrays" title="Maven-Central / org.apidesign.bck2brwsr / emul"><span>0.10</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apidesign.bck2brwsr/emul/0.9/java/util/Arrays.java#Arrays" title="Maven-Central / org.apidesign.bck2brwsr / emul"><span>0.9</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apidesign.bck2brwsr/emul/0.8.1/java/util/Arrays.java#Arrays" title="Maven-Central / org.apidesign.bck2brwsr / emul"><span>0.8.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apidesign.bck2brwsr/emul/0.8/java/util/Arrays.java#Arrays" title="Maven-Central / org.apidesign.bck2brwsr / emul"><span>0.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apidesign.bck2brwsr/emul/0.7.2/java/util/Arrays.java#Arrays" title="Maven-Central / org.apidesign.bck2brwsr / emul"><span>0.7.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apidesign.bck2brwsr/emul/0.7/java/util/Arrays.java#Arrays" title="Maven-Central / org.apidesign.bck2brwsr / emul"><span>0.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apidesign.bck2brwsr/emul/0.6/java/util/Arrays.java#Arrays" title="Maven-Central / org.apidesign.bck2brwsr / emul"><span>0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apidesign.bck2brwsr/emul/0.5/java/util/Arrays.java#Arrays" title="Maven-Central / org.apidesign.bck2brwsr / emul"><span>0.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apidesign.bck2brwsr/emul/0.4/java/util/Arrays.java#Arrays" title="Maven-Central / org.apidesign.bck2brwsr / emul"><span>0.4</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.1.1">
                
            </div><div class="container-group" id="container-group.9.2.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> dragome-js-jre</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.dragome/dragome-js-jre/0.96-beta2/java/util/Arrays.java#Arrays" title="Maven-Central / com.dragome / dragome-js-jre"><span>0.96-beta2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.dragome/dragome-js-jre/0.95.5-beta1/java/util/Arrays.java#Arrays" title="Maven-Central / com.dragome / dragome-js-jre"><span>0.95.5-beta1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.dragome/dragome-js-jre/0.95.2-beta1/java/util/Arrays.java#Arrays" title="Maven-Central / com.dragome / dragome-js-jre"><span>0.95.2-beta1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.dragome/dragome-js-jre/0.95.1-beta1/java/util/Arrays.java#Arrays" title="Maven-Central / com.dragome / dragome-js-jre"><span>0.95.1-beta1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.dragome/dragome-js-jre/0.95-beta1/java/util/Arrays.java#Arrays" title="Maven-Central / com.dragome / dragome-js-jre"><span>0.95-beta1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.2.1">
                
            </div><div class="container-group" id="container-group.9.3.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> robovm-rt</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.5.0/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.5.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.4.0/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.4.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.3.0/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.3.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.2.0/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.2.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.1.0/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.0.0/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.14/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.14</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.13/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.13</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.12/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.12</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.11/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.11</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.10/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.10</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.9/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.9</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.8/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.7/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.6/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.2/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.2</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.3.1">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> robovm-rt</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.5.0/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.5.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.4.0/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.4.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.3.0/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.3.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.2.0/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.2.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.1.0/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.0.0/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.0.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.0.0-beta-04/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.0.0-beta-04</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.0.0-beta-03/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.0.0-beta-03</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.0.0-beta-02/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.0.0-beta-02</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/1.0.0-beta-01/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>1.0.0-beta-01</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.14/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.14</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.13/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.13</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.12/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.12</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.11/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.11</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.10/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.10</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.9/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.9</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.8/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.7/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.6/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.5/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.4/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.3/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robovm/robovm-rt/0.0.2/java/util/Arrays.java#Arrays" title="Maven-Central / org.robovm / robovm-rt"><span>0.0.2</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.4.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> android-all</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robolectric/android-all/5.0.0_r2-robolectric-1/java/util/Arrays.java#Arrays" title="Maven-Central / org.robolectric / android-all"><span>5.0.0_r2-robolectric-1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robolectric/android-all/5.0.0_r2-robolectric-0/java/util/Arrays.java#Arrays" title="Maven-Central / org.robolectric / android-all"><span>5.0.0_r2-robolectric-0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.robolectric/android-all/4.4_r1-robolectric-1/java/util/Arrays.java#Arrays" title="Maven-Central / org.robolectric / android-all"><span>4.4_r1-robolectric-1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.4.1">
                
            </div><div class="container-group-hidden" id="container-group.9.5.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> ocap-api</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap-api/1.3.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap-api"><span>1.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap-api/1.3/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap-api"><span>1.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap-api/1.2.3/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap-api"><span>1.2.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap-api/1.2.2/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap-api"><span>1.2.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap-api/1.2.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap-api"><span>1.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap-api/1.2/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap-api"><span>1.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap-api/1.1.3/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap-api"><span>1.1.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap-api/1.1.2/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap-api"><span>1.1.2</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.5.1">
                
            </div><div class="container-group-hidden" id="container-group.9.6.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> ocap</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap/1.3.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap"><span>1.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap/1.3/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap"><span>1.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap/1.2.3/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap"><span>1.2.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap/1.2.2/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap"><span>1.2.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap/1.2.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap"><span>1.2.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap/1.2/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap"><span>1.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap/1.1.5/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap"><span>1.1.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap/1.1.4/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap"><span>1.1.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.googlecode.jinahya/ocap/1.1.3/java/util/Arrays.java#Arrays" title="Maven-Central / com.googlecode.jinahya / ocap"><span>1.1.3</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.6.1">
                
            </div><div class="container-group-hidden" id="container-group.9.7.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> vaadin-client</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.5.2/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.5.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.5.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.5.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.5.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.8/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.7/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.6/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.5/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.4/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.3/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.2/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.3.10/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.3.10</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.3.9/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.3.9</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.3.8/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.3.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.0.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.0.0</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.7.1">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> vaadin-client</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.5.2/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.5.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.5.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.5.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.5.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.8/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.7/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.6/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.5/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.4/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.3/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.2/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.4.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.4.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.3.10/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.3.10</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.3.9/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.3.9</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.3.8/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.3.8</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.3.7/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.3.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.3.6/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.3.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.3.5/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.3.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.3.4/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.3.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.3.3/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.3.3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.3.2/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.3.2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.3.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.3.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.3.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.3.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.2.7/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.2.7</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.2.6/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.2.6</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.2.5/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.2.5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.2.4/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.2.4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.2.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.2.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.1.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin/vaadin-client/7.0.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin / vaadin-client"><span>7.0.0</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.8.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> gwt-servlet</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.7.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.7.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.7.0-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.7.0-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.6.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.6.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.6.1-rc2/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.6.1-rc2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.6.1-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.6.1-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.6.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.6.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.6.0-rc4/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.6.0-rc4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.6.0-rc3/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.6.0-rc3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.5.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.5.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.5.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.4.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.4.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.3.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.3.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.2.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.2.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.1.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.1.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.1.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.0.4/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.0.4</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.8.1">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> gwt-servlet</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.7.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.7.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.7.0-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.7.0-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.6.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.6.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.6.1-rc2/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.6.1-rc2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.6.1-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.6.1-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.6.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.6.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.6.0-rc4/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.6.0-rc4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.6.0-rc3/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.6.0-rc3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.6.0-rc2/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.6.0-rc2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.5.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.5.1-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.5.1-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.5.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.5.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.5.0-rc2/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.5.0-rc2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.5.0-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.5.0-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.4.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.4.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.4.0-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.4.0-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.3.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.3.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.2.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.2.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.2-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.2-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.1.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.1.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.1.1-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.1.1-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.1.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-servlet/2.0.4/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-servlet"><span>2.0.4</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.9.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> org.apache.servicemix.bundles.gwt-servlet</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apache.servicemix.bundles/org.apache.servicemix.bundles.gwt-servlet/2.7.0_1/java/util/Arrays.java#Arrays" title="Maven-Central / org.apache.servicemix.bundles / org.apache.servicemix.bundles.gwt-servlet"><span>2.7.0_1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apache.servicemix.bundles/org.apache.servicemix.bundles.gwt-servlet/2.6.1_1/java/util/Arrays.java#Arrays" title="Maven-Central / org.apache.servicemix.bundles / org.apache.servicemix.bundles.gwt-servlet"><span>2.6.1_1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apache.servicemix.bundles/org.apache.servicemix.bundles.gwt-servlet/2.6.0_1/java/util/Arrays.java#Arrays" title="Maven-Central / org.apache.servicemix.bundles / org.apache.servicemix.bundles.gwt-servlet"><span>2.6.0_1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.9.1">
                
            </div><div class="container-group-hidden" id="container-group.9.10.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> gwt-user</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.7.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.7.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.7.0-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.7.0-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.7.0-beta1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.7.0-beta1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.6.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.6.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.6.1-rc2/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.6.1-rc2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.6.1-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.6.1-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.6.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.6.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.6.0-rc4/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.6.0-rc4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.5.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.5.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.5.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.4.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.4.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.3.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.3.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.2.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.2.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.1.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.1.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.1.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.0.4/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.0.4</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.10.1">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> gwt-user</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.7.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.7.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.7.0-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.7.0-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.7.0-beta1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.7.0-beta1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.6.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.6.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.6.1-rc2/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.6.1-rc2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.6.1-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.6.1-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.6.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.6.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.6.0-rc4/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.6.0-rc4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.6.0-rc3/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.6.0-rc3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.6.0-rc2/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.6.0-rc2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.6.0-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.6.0-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.5.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.5.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.5.1-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.5.1-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.5.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.5.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.5.0-rc2/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.5.0-rc2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.5.0-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.5.0-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.4.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.4.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.4.0-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.4.0-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.3.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.3.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.2.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.2.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.2-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.2-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.1.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.1.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.1.1-rc1/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.1.1-rc1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.1.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.1.0</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.google.gwt/gwt-user/2.0.4/java/util/Arrays.java#Arrays" title="Maven-Central / com.google.gwt / gwt-user"><span>2.0.4</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.11.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> gwt-servlet</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin.external.gwt/gwt-servlet/2.7.0.vaadin3/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin.external.gwt / gwt-servlet"><span>2.7.0.vaadin3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin.external.gwt/gwt-servlet/2.7.0.vaadin2/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin.external.gwt / gwt-servlet"><span>2.7.0.vaadin2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin.external.gwt/gwt-servlet/2.7.0.vaadin1/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin.external.gwt / gwt-servlet"><span>2.7.0.vaadin1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.11.1">
                
            </div><div class="container-group-hidden" id="container-group.9.12.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> gwt-user</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin.external.gwt/gwt-user/2.7.0.beta1vaadin1/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin.external.gwt / gwt-user"><span>2.7.0.beta1vaadin1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin.external.gwt/gwt-user/2.7.0.vaadin3/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin.external.gwt / gwt-user"><span>2.7.0.vaadin3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin.external.gwt/gwt-user/2.7.0.vaadin2/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin.external.gwt / gwt-user"><span>2.7.0.vaadin2</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin.external.gwt/gwt-user/2.7.0.vaadin1/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin.external.gwt / gwt-user"><span>2.7.0.vaadin1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin.external.gwt/gwt-user/2.6.0.vaadin5/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin.external.gwt / gwt-user"><span>2.6.0.vaadin5</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin.external.gwt/gwt-user/2.6.0.vaadin4/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin.external.gwt / gwt-user"><span>2.6.0.vaadin4</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin.external.gwt/gwt-user/2.6.0.vaadin3/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin.external.gwt / gwt-user"><span>2.6.0.vaadin3</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.vaadin.external.gwt/gwt-user/2.6.0.vaadin2/java/util/Arrays.java#Arrays" title="Maven-Central / com.vaadin.external.gwt / gwt-user"><span>2.6.0.vaadin2</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.12.1">
                
            </div><div class="container-group-hidden" id="container-group.9.13.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> gwt-servlet</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/net.wetheinter/gwt-servlet/2.7.0/java/util/Arrays.java#Arrays" title="Maven-Central / net.wetheinter / gwt-servlet"><span>2.7.0</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.13.1">
                
            </div><div class="container-group-hidden" id="container-group.9.14.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> gwt-user</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/net.wetheinter/gwt-user/2.7.0/java/util/Arrays.java#Arrays" title="Maven-Central / net.wetheinter / gwt-user"><span>2.7.0</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.14.1">
                
            </div><div class="container-group-hidden" id="container-group.9.15.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> org.apache.servicemix.bundles.gwt-user</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apache.servicemix.bundles/org.apache.servicemix.bundles.gwt-user/2.6.0_1/java/util/Arrays.java#Arrays" title="Maven-Central / org.apache.servicemix.bundles / org.apache.servicemix.bundles.gwt-user"><span>2.6.0_1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/org.apache.servicemix.bundles/org.apache.servicemix.bundles.gwt-user/2.4.0_1/java/util/Arrays.java#Arrays" title="Maven-Central / org.apache.servicemix.bundles / org.apache.servicemix.bundles.gwt-user"><span>2.4.0_1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.15.1">
                
            </div><div class="container-group-hidden" id="container-group.9.16.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> cdc-1.1.2-stub</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.github.mcpat.apistubs/cdc-1.1.2-stub/1.0.1/java/util/Arrays.java#Arrays" title="Maven-Central / com.github.mcpat.apistubs / cdc-1.1.2-stub"><span>1.0.1</span></a>
                </div><div class="result-list">
                    
                    
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/com.github.mcpat.apistubs/cdc-1.1.2-stub/1.0/java/util/Arrays.java#Arrays" title="Maven-Central / com.github.mcpat.apistubs / cdc-1.1.2-stub"><span>1.0</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.16.1">
                
            </div><div class="container-group-hidden" id="container-group.9.17.0">
                <div class="result-list">
                    
                    <span class="container-label"><img class='img_base img_jdt_obj16_library_obj' src='/static/app/images/1x1.gif' border='0' title='' width='16' height='16'></img> gwt-reflect</span>
                    <a class="container-name" href="../../../../../../../../../../../../../../../file/repo1.maven.org/maven2/net.wetheinter/gwt-reflect/2.5.1/java/util/Arrays.java#Arrays" title="Maven-Central / net.wetheinter / gwt-reflect"><span>2.5.1</span></a>
                </div>
            </div><div class="container-group-hidden" id="container-group.9.17.1">
                
            </div>
        </div>
    </div>
    

    <script type="text/javascript">
    function setEntityInput() {
        var eName = document.getElementById('entity-name-field').innerHTML;
        var eNameInput = document.getElementById('search-entity');

        if (eNameInput) {
            eNameInput.value = eName;
        }
    }
    YAHOO.util.Event.onDOMReady(setEntityInput, null, true);

    var CONTAINER_GROUP = "container-group";
    var CONTAINER_GROUP_HIDDEN = "container-group-hidden";

    function drawExpandLinks() {
        var moreGroupsIcon = document.getElementById("icon-project").innerHTML;

        for (var x=0; document.getElementById(getVersionGroupId(x, 0, 0)) != null; x++) {
            var moreGroupsLinkEl = null;

            for (var y=0;;y++) {
                var containerGroupElBrief = document.getElementById(getVersionGroupId(x, y, 0));
                if (containerGroupElBrief == null) {
                    break;
                }

                var containerGroupElAll = document.getElementById(getVersionGroupId(x, y, 1));
                if (containerGroupElAll != null && containerGroupElAll.innerHTML.match(/\S/)) {
                    var countHiddenVersions = containerGroupElAll.childNodes.length - containerGroupElBrief.childNodes.length;

                    containerGroupElBrief.innerHTML +=
                        "<div class='result-list'>" +
                        createClickableLink("...", countHiddenVersions+" more version(s)", "container-name", "activateVersionGroup("+x+","+y+",1)") +
                        "</div>";
                }
                
                if ((getClassAttribute(containerGroupElBrief) == CONTAINER_GROUP_HIDDEN)
                    && (moreGroupsLinkEl == null)) {
                    // was over visible limit
                    var hiddenGroupCount = 1 /*this*/ + countHiddenGroups(x, y+1) /*remaining*/;

                    moreGroupsLinkEl = document.createElement("div");
                    setClassAttribute(moreGroupsLinkEl, CONTAINER_GROUP);
                    moreGroupsLinkEl.innerHTML = moreGroupsIcon+"&nbsp;"+createClickableLink("...", hiddenGroupCount+" more project(s)", "container-name", "activateProjectGroups(this.parentNode)");
                    containerGroupElBrief.parentNode.insertBefore(moreGroupsLinkEl, containerGroupElBrief);
                }
            }
        }
    }
    YAHOO.util.Event.onDOMReady(drawExpandLinks, null, true);

    function countHiddenGroups(x, y) {
        var i;
        for (i=0; document.getElementById(getVersionGroupId(x, y+i, 0)) != null; i++) { }
        return i;
    }

    function activateVersionGroup(x, y, z) {
        // hide previous
        setClassAttribute(document.getElementById(getVersionGroupId(x,y,z-1)), CONTAINER_GROUP_HIDDEN);
        // show this
        setClassAttribute(document.getElementById(getVersionGroupId(x,y,z)), CONTAINER_GROUP);
    }

    function getVersionGroupId(x, y, z) {
        return CONTAINER_GROUP+"."+x+"."+y+"."+z;
    }

    function activateProjectGroups(node) {
        var following = false;
        var ch = node.parentNode.childNodes;
        for (var i=0, ln=ch.length; i<ln; i++) {
            var c = ch.item(i);
            if (following) {
                if (/\.0$/.test(c.id)) {
                    setClassAttribute(c, CONTAINER_GROUP);
                }
            }
            else if (c == node) {
                following = true;
            }
        }
        // hide link
        setClassAttribute(node, CONTAINER_GROUP_HIDDEN);
    }

    function createClickableLink(linkText, linkTitle, linkClass, onClickFunc) {
        var onClickHandler = "this.blur();"+onClickFunc+";return false;";
        return "<a class='"+linkClass+"' title='"+linkTitle+"' href='#' onclick='"+onClickHandler+"'>"+linkText+"</a>";
    }

    </script>
</div>
</div>

                <div class="search-tabs-bottom">
                    <div class="search-tab-unselected">
                        <span class="search-tab-prefix-bottom"></span>
                        <span class="search-tab-name-bottom"
                            ><a href="../../../../../../../../../../../../../../../search/?start=10&amp;query=org+pentaho+metadata+query+model+util+FormatterHits.java&amp;entity=type"><span>Next</span></a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div>
    <div id="context-menu-panel" class='context-menu-panel' style='visibility: hidden;'></div>
    <div id="context-menu-panel-data" style='visibility: hidden;'></div>
</div>


        
        
            <div id="notification-bar">
                <table width="100%" border="0">
                    <tr valign="middle">
                        <td valign="middle"><span class="message">New to GrepCode? Check out our <a href="/faq" onclick="disableNotification(); return true;">FAQ</a></span></td>
                        <td valign="middle"><span class="cancel"><a href="#" onclick="disableNotification(); return false;">X</a></span></td>
                    </tr>
                </table>
            </div>
            <script type="text/javascript">
                YAHOO.util.Event.onDOMReady(doNotification);
            </script>
        
        
        

        

        

        
        
            <script type="text/javascript">
            try {
                pageTracker._trackPageview();
            } catch(err) {
            }
            </script>
        

        
        

        
    </body>
</html>
