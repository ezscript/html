package org.pentaho.ui.xul.swt.tags.treeutil;

import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.swt.widgets.Tree;

public class XulTreeTextCellEditor extends TextCellEditor {

  public XulTreeTextCellEditor(Tree t){
    super(t);
  }
}
